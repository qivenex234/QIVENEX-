#!/bin/sh
set -eu
cd /workspace
node scripts/preview.mjs stop || true
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi
# Server-only administrator bootstrap. Never imported into the browser bundle.
export QIVENEX_ADMIN_ACCESS_CODE='ch234@vincent'
npm run dev >>/tmp/app-startup.log 2>&1 &
