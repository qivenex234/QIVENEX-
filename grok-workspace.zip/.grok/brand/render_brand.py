"""QIVENEX AI ACADEMY brand assets: favicon SVG + 1200x630 card master PNG."""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path("/workspace/.grok/brand")
FONTS = Path("/workspace/.grok/fonts")
FONT_Q = FONTS / "cg-600.ttf"
FONT_TITLE = FONTS / "cg-600.ttf"
FONT_SUB = FONTS / "cg-500i.ttf"

CHAR = (0x14, 0x12, 0x10)
PAPER = (0xF4, 0xEF, 0xE6)
GOLD = (0xA8, 0x84, 0x3F)
INK = (0x2A, 0x24, 0x1C)

W, H = 1200, 630


def glyph_path(font_path: Path, char: str) -> tuple[str, tuple[float, float, float, float]]:
    font = TTFont(str(font_path))
    gs = font.getGlyphSet()
    name = font.getBestCmap()[ord(char)]
    pen = SVGPathPen(gs)
    gs[name].draw(pen)
    bounds = BoundsPen(gs)
    gs[name].draw(bounds)
    return pen.getCommands(), bounds.bounds


def write_favicon(path: Path) -> None:
    d, (x0, y0, x1, y1) = glyph_path(FONT_Q, "Q")
    cx = (x0 + x1) / 2
    cy = (y0 + y1) / 2
    # Fit the swash Q inside the tile with room for the gold bar.
    bw, bh = x1 - x0, y1 - y0
    target = 42.0
    scale = target / max(bw, bh)
    # Visual center sits a touch high so the tail and bar have air.
    tx, ty = 32.0, 29.5
    # Bowl (not the tail) lives in the upper part of the glyph. Place a short
    # gold bar under the bowl, right of center — the temporary monogram mark.
    # Font y-up, after translate(tx,ty) scale(s,-s) around glyph center:
    # screen = (tx, ty) + scale * (font - center) with y flipped.
    def to_screen(fx: float, fy: float) -> tuple[float, float]:
        return (tx + scale * (fx - cx), ty - scale * (fy - cy))

    # Bowl baseline is near font y=0; tail descends below. Bar sits on that
    # baseline, toward the right side of the bowl, short and horizontal.
    bowl_right = x0 + bw * 0.62
    bar_left_f = x0 + bw * 0.42
    p1 = to_screen(bar_left_f, 18)
    p2 = to_screen(bowl_right, 18)
    bar_w = abs(p2[0] - p1[0])
    bar_h = 2.15
    bar_x = min(p1[0], p2[0])
    bar_y = p1[1] - bar_h / 2

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="10" fill="#141210"/>
  <g transform="translate({tx:.3f} {ty:.3f}) scale({scale:.6f} {-scale:.6f}) translate({-cx:.3f} {-cy:.3f})">
    <path fill="#f4efe6" d="{d}"/>
  </g>
  <rect x="{bar_x:.2f}" y="{bar_y:.2f}" width="{bar_w:.2f}" height="{bar_h:.2f}" rx="0.4" fill="#a8843f"/>
</svg>
"""
    path.write_text(svg)
    print("favicon", path, "bar", round(bar_x, 2), round(bar_y, 2), round(bar_w, 2))


def text_width(font: ImageFont.FreeTypeFont, text: str, tracking: float) -> float:
    if not text:
        return 0.0
    return sum(font.getlength(ch) for ch in text) + tracking * (len(text) - 1)


def draw_tracked(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.FreeTypeFont,
    fill: tuple[int, int, int],
    y: float,
    tracking: float,
    canvas_w: int,
    alpha: int = 255,
) -> float:
    total = text_width(font, text, tracking)
    x = (canvas_w - total) / 2
    color = (*fill, alpha)
    for ch in text:
        draw.text((x, y), ch, font=font, fill=color)
        x += font.getlength(ch) + tracking
    return total


def render_card(path: Path) -> None:
    rng = np.random.default_rng(12)
    # Charcoal field, a breath warmer in the center — no scenery, no people.
    yy, xx = np.mgrid[0:H, 0:W]
    nx = (xx - W / 2) / (W * 0.72)
    ny = (yy - H / 2) / (H * 0.78)
    glow = np.clip(1 - (nx * nx + ny * ny), 0, 1) ** 1.35
    base = np.zeros((H, W, 3), dtype=np.float32)
    for i, (c0, c1) in enumerate(zip(CHAR, (0x22, 0x1C, 0x16))):
        base[:, :, i] = c0 + (c1 - c0) * glow * 0.85
    # Antique-gold warmth, very low, behind the lockup only.
    gold_glow = np.clip(1 - ((xx - W / 2) ** 2) / (340**2) - ((yy - H * 0.40) ** 2) / (180**2), 0, 1)
    gold_glow = gold_glow**1.6
    base[:, :, 0] += gold_glow * 18
    base[:, :, 1] += gold_glow * 12
    base[:, :, 2] += gold_glow * 4
    grain = rng.normal(0, 2.1, (H, W, 1)).astype(np.float32)
    base = np.clip(base + grain, 0, 255).astype(np.uint8)
    img = Image.fromarray(base, "RGB").convert("RGBA")

    # Hairline frame — quiet, not a certificate border.
    frame = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    fd = ImageDraw.Draw(frame)
    inset = 36
    fd.rectangle(
        [inset, inset, W - 1 - inset, H - 1 - inset],
        outline=(*GOLD, 78),
        width=1,
    )
    img = Image.alpha_composite(img, frame)

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    q_size = 210
    q_font = ImageFont.truetype(str(FONT_Q), q_size)
    # Measure ink of Q so the monogram can be centered on its visual mass.
    q_img = Image.new("L", (700, 520), 0)
    qd = ImageDraw.Draw(q_img)
    qd.text((20, 20), "Q", font=q_font, fill=255)
    mask = np.array(q_img)
    ys, xs = np.where(mask > 16)
    qx0, qy0, qx1, qy1 = xs.min(), ys.min(), xs.max(), ys.max()
    q_crop = q_img.crop((qx0, qy0, qx1 + 1, qy1 + 1))
    qw, qh = q_crop.size

    # Center the monogram block slightly above the mathematical middle so the
    # wordmark sits in the optical center of the card.
    title_font = ImageFont.truetype(str(FONT_TITLE), 78)
    academy_font = ImageFont.truetype(str(FONT_TITLE), 40)
    sub_font = ImageFont.truetype(str(FONT_SUB), 26)

    title = "QIVENEX"
    academy = "AI ACADEMY"
    subtitle = "Learn AI. Build Your Ideas. Create Your Future."
    title_track = 10.0
    academy_track = 8.5
    sub_track = 0.6

    title_w = text_width(title_font, title, title_track)
    academy_w = text_width(academy_font, academy, academy_track)
    sub_w = text_width(sub_font, subtitle, sub_track)
    print("widths", round(qw), round(title_w), round(academy_w), round(sub_w))

    gap_after_q = 18
    gap_title = 0
    gap_before_rule = 22
    rule_h = 1
    gap_after_rule = 16
    # Approximate text block heights from font size (Cormorant is tall).
    title_h = 78
    academy_h = 42
    sub_h = 30
    block_h = qh + gap_after_q + title_h + gap_title + academy_h + gap_before_rule + rule_h + gap_after_rule + sub_h
    top = int((H - block_h) / 2) - 6
    print("block", block_h, "top", top, "bottom margin", H - (top + block_h))

    q_x = (W - qw) // 2
    q_y = top
    # Paper Q
    q_rgba = Image.new("RGBA", q_crop.size, (*PAPER, 0))
    q_rgba.putalpha(q_crop)
    overlay.alpha_composite(q_rgba, (q_x, q_y))

    # Small gold bar under the bowl, clear of the swash terminal.
    # Bowl occupies the left ~68% of the glyph; tail sweeps right and down.
    bar_w = 54
    bar_h = 5
    bar_x = q_x + int(qw * 0.34)
    bar_y = q_y + int(qh * 0.78)
    draw.rounded_rectangle(
        [bar_x, bar_y, bar_x + bar_w, bar_y + bar_h],
        radius=1,
        fill=(*GOLD, 255),
    )

    y = q_y + qh + gap_after_q
    # Optical lift: FreeType y is the top of the em box, which includes extra
    # headroom. Nudge title up a few pixels so the gap after the tail feels even.
    y -= 8
    draw_tracked(draw, title, title_font, PAPER, y, title_track, W)
    y += title_h + gap_title
    draw_tracked(draw, academy, academy_font, GOLD, y, academy_track, W)
    y += academy_h + gap_before_rule
    rule_w = 72
    rx0 = (W - rule_w) // 2
    draw.rectangle([rx0, y, rx0 + rule_w, y + rule_h], fill=(*GOLD, 210))
    y += rule_h + gap_after_rule
    draw_tracked(draw, subtitle, sub_font, PAPER, y, sub_track, W, alpha=210)

    img = Image.alpha_composite(img, overlay)
    # Soft vignette so the edges fall quiet.
    vig = np.zeros((H, W), dtype=np.float32)
    yy, xx = np.mgrid[0:H, 0:W]
    r = np.sqrt(((xx - W / 2) / (W * 0.62)) ** 2 + ((yy - H / 2) / (H * 0.70)) ** 2)
    vig = np.clip((r - 0.72) / 0.55, 0, 1) ** 1.4
    arr = np.array(img).astype(np.float32)
    arr[:, :, 0] *= 1 - vig * 0.28
    arr[:, :, 1] *= 1 - vig * 0.28
    arr[:, :, 2] *= 1 - vig * 0.28
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    out = Image.fromarray(arr, "RGBA").convert("RGB")
    out.save(path, "PNG", optimize=True)
    print("wrote", path, out.size)


if __name__ == "__main__":
    write_favicon(ROOT / "favicon.svg")
    render_card(ROOT / "og-master.png")
