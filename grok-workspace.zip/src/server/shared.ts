import { getSql, type Sql } from "@/lib/db";
import {
  OFFICIAL,
  asSections,
  asStringArray,
  fallbackChrome,
  httpsUrl,
  planRank,
  type Accent,
  type Chrome,
  type CourseCard,
  type Difficulty,
  type Plan,
  type PlanCode,
  type ThemeMode,
} from "@/lib/academy";

export type Member = {
  userId: string;
  displayName: string;
  email: string | null;
  role: "student" | "admin";
  status: "active" | "suspended";
};

type SettingsRow = {
  hero_kicker: string;
  hero_title: string;
  hero_body: string;
  about_title: string;
  about_body: string;
  founder_note: string;
  contact_email: string | null;
  contact_note: string;
  seo_title: string;
  seo_description: string;
  canonical_url: string;
  theme_mode: string;
  accent: string;
  youtube_url: string;
  whatsapp_url: string;
  facebook_url: string | null;
  instagram_url: string | null;
  tiktok_url: string | null;
  x_url: string | null;
  linkedin_url: string | null;
  show_header_social: boolean;
  show_footer_social: boolean;
  sections: unknown;
  has_logo: boolean;
  has_custom_hero: boolean;
  has_custom_about: boolean;
  auto_issue_certificates: boolean;
};

const THEMES = new Set<ThemeMode>(["system", "light", "dark"]);
const ACCENTS = new Set<Accent>(["gold", "blue", "violet"]);
const DIFFICULTIES = new Set<Difficulty>(["beginner", "intermediate", "advanced"]);
const PLANS = new Set<PlanCode>(["starter", "basic", "standard"]);

export function isDifficulty(value: string): value is Difficulty {
  return DIFFICULTIES.has(value as Difficulty);
}

export function isPlan(value: string): value is PlanCode {
  return PLANS.has(value as PlanCode);
}

export function isTheme(value: string): value is ThemeMode {
  return THEMES.has(value as ThemeMode);
}

export function isAccent(value: string): value is Accent {
  return ACCENTS.has(value as Accent);
}

export function clip(value: string, max: number): string {
  return value.trim().slice(0, max);
}

export async function db(): Promise<Sql> {
  return getSql();
}

export async function assertSameSite(): Promise<void> {
  const { assertSameSiteRequest } = await import("@/lib/auth/isolation.server");
  assertSameSiteRequest();
}

export async function clientBucket(prefix: string): Promise<string> {
  const { createHash } = await import("node:crypto");
  let ip = "unknown";
  try {
    const { getRequest } = await import("@tanstack/react-start/server");
    const header = getRequest().headers.get("x-forwarded-for") ?? "";
    ip = header.split(",")[0]?.trim() || "local";
  } catch {
    ip = "local";
  }
  const hash = createHash("sha256").update(ip).digest("hex").slice(0, 20);
  return `${prefix}:${hash}`;
}

/** Returns true when the caller should be blocked. */
export async function rateLimited(bucket: string, limit: number, windowSec: number): Promise<boolean> {
  const sql = await db();
  const rows = await sql<{ hits: number; age_seconds: number }>`
    select hits, extract(epoch from (now() - window_start))::int as age_seconds
    from rate_limits where bucket = ${bucket}
  `;
  const row = rows[0];
  if (!row || row.age_seconds > windowSec) {
    await sql`
      insert into rate_limits (bucket, hits, window_start) values (${bucket}, 1, now())
      on conflict (bucket) do update set hits = 1, window_start = now()
    `;
    return false;
  }
  if (row.hits >= limit) return true;
  await sql`update rate_limits set hits = hits + 1 where bucket = ${bucket}`;
  return false;
}

export async function audit(
  actorId: string | null,
  action: string,
  entity: string,
  entityId: string | null,
  detail: string,
): Promise<void> {
  const sql = await db();
  await sql`
    insert into audit_logs (actor_id, action, entity, entity_id, detail)
    values (${actorId}, ${clip(action, 80)}, ${clip(entity, 40)}, ${entityId}, ${clip(detail, 240)})
  `;
}

export async function loadMember(userId: string): Promise<Member> {
  const sql = await db();
  const users = await sql<{ name: string; email: string }>`
    select name, email from "user" where id = ${userId}
  `;
  const name = clip(users[0]?.name || "Student", 80) || "Student";
  const email = users[0]?.email ?? null;
  await sql`
    insert into profiles (user_id, display_name, role, status)
    values (${userId}, ${name}, 'student', 'active')
    on conflict (user_id) do nothing
  `;
  const rows = await sql<{ display_name: string; role: "student" | "admin"; status: "active" | "suspended" }>`
    select display_name, role, status from profiles where user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) throw new Error("Could not open your profile.");
  return {
    userId,
    displayName: row.display_name,
    email,
    role: row.role,
    status: row.status,
  };
}

export async function requireAdmin(userId: string): Promise<Member> {
  const member = await loadMember(userId);
  if (member.role !== "admin" || member.status !== "active") {
    throw new Error("Forbidden");
  }
  return member;
}

export function mapChrome(row: SettingsRow | undefined): Chrome {
  if (!row) return fallbackChrome();
  const base = fallbackChrome();
  return {
    heroKicker: row.hero_kicker || base.heroKicker,
    heroTitle: row.hero_title || base.heroTitle,
    heroBody: row.hero_body || base.heroBody,
    aboutTitle: row.about_title || base.aboutTitle,
    aboutBody: row.about_body || base.aboutBody,
    founderNote: row.founder_note || base.founderNote,
    contactEmail: httpsMail(row.contact_email),
    contactNote: row.contact_note || base.contactNote,
    seoTitle: row.seo_title || base.seoTitle,
    seoDescription: row.seo_description || base.seoDescription,
    canonicalUrl: (httpsUrl(row.canonical_url) ?? base.canonicalUrl).replace(/\/$/, ""),
    themeMode: isTheme(row.theme_mode) ? row.theme_mode : "system",
    accent: isAccent(row.accent) ? row.accent : "gold",
    youtubeUrl: httpsUrl(row.youtube_url) ?? OFFICIAL.youtube,
    whatsappUrl: httpsUrl(row.whatsapp_url) ?? OFFICIAL.whatsapp,
    facebookUrl: httpsUrl(row.facebook_url),
    instagramUrl: httpsUrl(row.instagram_url),
    tiktokUrl: httpsUrl(row.tiktok_url),
    xUrl: httpsUrl(row.x_url),
    linkedinUrl: httpsUrl(row.linkedin_url),
    showHeaderSocial: row.show_header_social,
    showFooterSocial: row.show_footer_social,
    sections: asSections(row.sections),
    hasLogo: row.has_logo,
    hasCustomHero: row.has_custom_hero,
    hasCustomAbout: row.has_custom_about,
    autoIssueCertificates: row.auto_issue_certificates,
  };
}

function httpsMail(value: string | null): string | null {
  const email = (value ?? "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}

export async function readChrome(): Promise<Chrome> {
  const sql = await db();
  const rows = await sql<SettingsRow>`
    select hero_kicker, hero_title, hero_body, about_title, about_body, founder_note,
      contact_email, contact_note, seo_title, seo_description, canonical_url,
      theme_mode, accent, youtube_url, whatsapp_url, facebook_url, instagram_url,
      tiktok_url, x_url, linkedin_url, show_header_social, show_footer_social, sections,
      (logo_data is not null) as has_logo,
      (hero_image is not null) as has_custom_hero,
      (about_image is not null) as has_custom_about,
      auto_issue_certificates
    from site_settings where id = 1
  `;
  return mapChrome(rows[0]);
}

type CourseRow = {
  id: number;
  slug: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  plan_code: string | null;
  checkout_url: string | null;
  outcomes: unknown;
  curriculum: string | null;
  cover: string | null;
  published: boolean;
  sort_order: number;
  lesson_count: number;
};

export function mapCourse(row: CourseRow): CourseCard {
  const difficulty: Difficulty = isDifficulty(row.difficulty) ? row.difficulty : "beginner";
  const planCode = row.plan_code && isPlan(row.plan_code) ? row.plan_code : null;
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    category: row.category,
    difficulty,
    planCode,
    checkoutUrl: httpsUrl(row.checkout_url),
    outcomes: asStringArray(row.outcomes),
    curriculum: row.curriculum,
    cover: row.cover,
    published: row.published,
    sortOrder: row.sort_order,
    lessonCount: Number(row.lesson_count ?? 0),
  };
}

export async function readPlans(onlyPublished: boolean): Promise<Plan[]> {
  const sql = await db();
  const rows = await sql<{
    code: string;
    name: string;
    price_ngn: number;
    description: string;
    features: unknown;
    checkout_url: string;
    published: boolean;
    sort_order: number;
  }>`
    select code, name, price_ngn, description, features, checkout_url, published, sort_order
    from plans
    order by sort_order, code
  `;
  return rows
    .filter((row) => isPlan(row.code) && (!onlyPublished || row.published))
    .map((row) => ({
      code: row.code as PlanCode,
      name: row.name,
      priceNgn: row.price_ngn,
      description: row.description,
      features: asStringArray(row.features),
      checkoutUrl: httpsUrl(row.checkout_url) ?? OFFICIAL.selar[row.code as PlanCode],
      published: row.published,
      sortOrder: row.sort_order,
    }));
}

export async function courseUnlocked(
  userId: string,
  course: { id: number; planCode: PlanCode | null },
): Promise<boolean> {
  const sql = await db();
  const rows = await sql<{ plan_code: string | null; course_id: number | null }>`
    select plan_code, course_id from enrollments
    where user_id = ${userId} and status = 'verified'
  `;
  let best = 0;
  const direct = new Set<number>();
  for (const row of rows) {
    if (row.course_id) direct.add(row.course_id);
    best = Math.max(best, planRank(row.plan_code));
  }
  if (direct.has(course.id)) return true;
  const need = planRank(course.planCode);
  return need > 0 && best >= need;
}

export function imageData(value: string): string | null {
  const match = value.match(/^data:(image\/(?:jpeg|png|webp));base64,([a-zA-Z0-9+/=]+)$/);
  if (!match) return null;
  if (value.length > 480_000) return null;
  return value;
}

export async function readBrand(column: "logo_data" | "favicon_data" | "hero_image" | "about_image"): Promise<string | null> {
  const sql = await db();
  const rows = await sql.query<{ data: string | null }>(
    `select ${column} as data from site_settings where id = 1`,
    [],
  );
  return rows[0]?.data ?? null;
}

const CARD_PATTERN = /(?:\d[ -]?){13,19}/;

export function cleanNote(value: string): string {
  const note = clip(value, 200);
  if (CARD_PATTERN.test(note.replace(/\s/g, " "))) {
    throw new Error("Do not store card numbers in a note.");
  }
  return note;
}

export async function accessCodeMatches(code: string): Promise<true | false | "unconfigured"> {
  const sql = await db();
  const rows = await sql<{ hash: string }>`select hash from admin_credential where id = 1`;
  const { scryptSync, timingSafeEqual, createHash } = await import("node:crypto");
  if (rows[0]?.hash) return verifyScrypt(code, rows[0].hash, scryptSync, timingSafeEqual);
  const expected = process.env.QIVENEX_ADMIN_ACCESS_CODE;
  if (!expected) return "unconfigured";
  const left = createHash("sha256").update(code).digest();
  const right = createHash("sha256").update(expected).digest();
  return timingSafeEqual(left, right);
}

export async function storeAccessHash(code: string): Promise<void> {
  const { scryptSync, randomBytes } = await import("node:crypto");
  const salt = randomBytes(16).toString("hex");
  const hash = `scrypt$${salt}$${scryptSync(code, salt, 32).toString("hex")}`;
  const sql = await db();
  await sql`
    insert into admin_credential (id, hash, updated_at) values (1, ${hash}, now())
    on conflict (id) do update set hash = ${hash}, updated_at = now()
  `;
}

function verifyScrypt(
  code: string,
  stored: string,
  scryptSync: (password: string, salt: string, keylen: number) => Buffer,
  timingSafeEqual: (a: Buffer, b: Buffer) => boolean,
): boolean {
  const [kind, salt, hash] = stored.split("$");
  if (kind !== "scrypt" || !salt || !hash) return false;
  const got = scryptSync(code, salt, 32);
  const expected = Buffer.from(hash, "hex");
  if (got.length !== expected.length) return false;
  return timingSafeEqual(got, expected);
}

export async function adminConfigured(): Promise<boolean> {
  const sql = await db();
  const rows = await sql<{ id: number }>`select id from admin_credential where id = 1`;
  return rows.length > 0 || Boolean(process.env.QIVENEX_ADMIN_ACCESS_CODE);
}
