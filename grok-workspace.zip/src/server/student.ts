import { createServerFn } from "@tanstack/react-start";
import { buildCertificatePdf } from "@/lib/pdf";
import { asStringArray, httpsUrl } from "@/lib/academy";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  accessCodeMatches,
  adminConfigured,
  assertSameSite,
  audit,
  cleanNote,
  clip,
  courseUnlocked,
  db,
  imageData,
  isPlan,
  loadMember,
  mapCourse,
  rateLimited,
  storeAccessHash,
} from "@/server/shared";

export const getMyAccess = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const member = await loadMember(context.userId);
    return {
      role: member.role,
      status: member.status,
      displayName: member.displayName,
      email: member.email,
      adminConfigured: member.role === "admin" ? true : await adminConfigured(),
    };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { displayName: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    const member = await loadMember(context.userId);
    if (member.status !== "active") throw new Error("This account is suspended.");
    const displayName = clip(data.displayName, 80);
    if (displayName.length < 2) return { ok: false as const, error: "Enter the name you want shown." };
    const sql = await db();
    await sql`
      update profiles set display_name = ${displayName}, updated_at = now()
      where user_id = ${context.userId}
    `;
    return { ok: true as const, displayName };
  });

export const getLearning = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const member = await loadMember(context.userId);
    const sql = await db();
    const courseRows = await sql<Parameters<typeof mapCourse>[0]>`
      select c.id, c.slug, c.title, c.description, c.category, c.difficulty, c.plan_code,
        c.checkout_url, c.outcomes, c.curriculum, c.cover, c.published, c.sort_order,
        (select count(*)::int from lessons l where l.course_id = c.id) as lesson_count
      from courses c
      where c.published = true
      order by c.sort_order, c.id
    `;
    const courses = [];
    for (const row of courseRows) {
      const course = mapCourse(row);
      courses.push({ ...course, unlocked: await courseUnlocked(context.userId, course) });
    }
    const enrollments = await sql<{
      id: number;
      plan_code: string | null;
      course_title: string | null;
      status: string;
      source: string;
      note: string | null;
      created_on: string;
    }>`
      select e.id, e.plan_code, c.title as course_title, e.status, e.source, e.note,
        to_char(e.created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from enrollments e
      left join courses c on c.id = e.course_id
      where e.user_id = ${context.userId}
      order by e.created_at desc
    `;
    const submissions = await sql<{
      id: number;
      title: string;
      description: string;
      skills: string;
      status: string;
      showcase: boolean;
      admin_note: string | null;
      created_on: string;
    }>`
      select id, title, description, skills, status, showcase, admin_note,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from submissions where user_id = ${context.userId}
      order by created_at desc
    `;
    const announcements = await sql<{ id: number; title: string; body: string; kind: string; created_on: string }>`
      select id, title, body, kind, to_char(created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from announcements where published = true order by created_at desc limit 8
    `;
    return { member, courses, enrollments, submissions, announcements };
  });

export const getLessons = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((slug: string) => slug.trim().slice(0, 80))
  .handler(async ({ context, data }) => {
    const member = await loadMember(context.userId);
    if (member.status !== "active") throw new Error("This account is suspended.");
    const sql = await db();
    const rows = await sql<Parameters<typeof mapCourse>[0]>`
      select c.id, c.slug, c.title, c.description, c.category, c.difficulty, c.plan_code,
        c.checkout_url, c.outcomes, c.curriculum, c.cover, c.published, c.sort_order,
        (select count(*)::int from lessons l where l.course_id = c.id) as lesson_count
      from courses c where c.slug = ${data}
    `;
    const course = rows[0] ? mapCourse(rows[0]) : null;
    if (!course || !course.published) return { course: null, lessons: [], unlocked: false };
    const unlocked = await courseUnlocked(context.userId, course);
    if (!unlocked) return { course, lessons: [], unlocked: false };
    const lessons = await sql<{ id: number; title: string; body: string; material_url: string | null }>`
      select id, title, body, material_url from lessons
      where course_id = ${course.id}
      order by sort_order, id
    `;
    return { course, lessons, unlocked: true };
  });

export const recordCheckoutIntent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { planCode?: string; courseId?: number }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    const member = await loadMember(context.userId);
    if (member.status !== "active") return { ok: false as const };
    const planCode = data.planCode && isPlan(data.planCode) ? data.planCode : null;
    const courseId = Number.isInteger(data.courseId) ? data.courseId : null;
    if (!planCode && !courseId) return { ok: false as const };
    if (await rateLimited(`checkout:${context.userId}`, 12, 60 * 60)) return { ok: true as const };
    const sql = await db();
    const existing = await sql<{ id: number }>`
      select id from enrollments
      where user_id = ${context.userId}
        and status = 'pending'
        and source = 'checkout_click'
        and plan_code is not distinct from ${planCode}
        and course_id is not distinct from ${courseId}
        and created_at > now() - interval '1 day'
      limit 1
    `;
    if (!existing[0]) {
      await sql`
        insert into enrollments (user_id, course_id, plan_code, status, source, note)
        values (
          ${context.userId}, ${courseId}, ${planCode}, 'pending', 'checkout_click',
          'Opened the Selar checkout. Payment is not confirmed.'
        )
      `;
    }
    return { ok: true as const };
  });

export const claimPayment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { planCode: string; note: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    const member = await loadMember(context.userId);
    if (member.status !== "active") return { ok: false as const, error: "This account is suspended." };
    if (!isPlan(data.planCode)) return { ok: false as const, error: "Choose a plan." };
    const note = cleanNote(data.note || "Student says they have paid. Not verified.");
    const sql = await db();
    const existing = await sql<{ id: number }>`
      select id from enrollments
      where user_id = ${context.userId} and plan_code = ${data.planCode} and status = 'pending'
        and source = 'manual_claim' and created_at > now() - interval '2 days'
      limit 1
    `;
    if (!existing[0]) {
      await sql`
        insert into enrollments (user_id, plan_code, status, source, note)
        values (${context.userId}, ${data.planCode}, 'pending', 'manual_claim', ${note})
      `;
    }
    return { ok: true as const };
  });

export const submitWork = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string; description: string; skills: string; media: string; videoUrl: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    const member = await loadMember(context.userId);
    if (member.status !== "active") return { ok: false as const, error: "This account is suspended." };
    if (await rateLimited(`work:${context.userId}`, 8, 60 * 60)) {
      return { ok: false as const, error: "Please wait before sending more work." };
    }
    const title = clip(data.title, 120);
    const description = clip(data.description, 2000);
    const skills = clip(data.skills, 200);
    if (title.length < 3 || description.length < 20) {
      return { ok: false as const, error: "Add a title and a short description of the work." };
    }
    const media = data.media ? imageData(data.media) : null;
    if (data.media && !media) return { ok: false as const, error: "Use a JPG, PNG, or WebP image under the size limit." };
    const video = data.videoUrl.trim() ? httpsUrl(data.videoUrl) : null;
    if (data.videoUrl.trim() && !video) return { ok: false as const, error: "Video links must start with https." };
    const sql = await db();
    await sql`
      insert into submissions (user_id, title, description, skills, media_data, video_url, status, showcase)
      values (${context.userId}, ${title}, ${description}, ${skills}, ${media}, ${video}, 'pending', false)
    `;
    return { ok: true as const };
  });

export const listStudentExams = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await loadMember(context.userId);
    const sql = await db();
    const exams = await sql<{
      id: number;
      title: string;
      instructions: string;
      pass_mark: number;
      deadline: string | null;
      question_count: number;
    }>`
      select e.id, e.title, e.instructions, e.pass_mark,
        to_char(e.deadline at time zone 'UTC', 'YYYY-MM-DD HH24:MI') as deadline,
        (select count(*)::int from exam_questions q where q.exam_id = e.id) as question_count
      from exams e
      where e.published = true
      order by e.id desc
    `;
    const attempts = await sql<{ exam_id: number; score: number; max_score: number; passed: boolean }>`
      select exam_id, score, max_score, passed from exam_attempts where user_id = ${context.userId}
    `;
    const certificates = await sql<{
      public_id: string;
      title: string;
      exam_id: number | null;
      issued_on: string;
    }>`
      select public_id, title, exam_id, to_char(issued_at at time zone 'UTC', 'YYYY-MM-DD') as issued_on
      from certificates where user_id = ${context.userId} order by issued_at desc
    `;
    const questions = await sql<{ id: number; exam_id: number; prompt: string; options: unknown }>`
      select id, exam_id, prompt, options from exam_questions order by sort_order, id
    `;
    return {
      exams: exams.map((exam) => ({
        id: exam.id,
        title: exam.title,
        instructions: exam.instructions,
        passMark: exam.pass_mark,
        deadline: exam.deadline,
        questionCount: exam.question_count,
        questions: questions
          .filter((q) => q.exam_id === exam.id)
          .map((q) => ({ id: q.id, prompt: q.prompt, options: asStringArray(q.options) })),
        attempt: attempts.find((a) => a.exam_id === exam.id) ?? null,
      })),
      certificates,
    };
  });

export const submitExam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { examId: number; answers: Array<{ questionId: number; choice: number }> }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    const member = await loadMember(context.userId);
    if (member.status !== "active") return { ok: false as const, error: "This account is suspended." };
    const examId = Number(data.examId);
    if (!Number.isInteger(examId)) return { ok: false as const, error: "That exam is not available." };
    const sql = await db();
    const exams = await sql<{ id: number; title: string; pass_mark: number; open: boolean }>`
      select id, title, pass_mark, (deadline is null or deadline > now()) as open
      from exams where id = ${examId} and published = true
    `;
    const exam = exams[0];
    if (!exam) return { ok: false as const, error: "That exam is not available." };
    if (!exam.open) return { ok: false as const, error: "The deadline for this exam has passed." };
    const prior = await sql<{ id: number }>`
      select id from exam_attempts where exam_id = ${examId} and user_id = ${context.userId}
    `;
    if (prior[0]) return { ok: false as const, error: "You have already submitted this exam." };
    const questions = await sql<{ id: number; correct_index: number; points: number }>`
      select id, correct_index, points from exam_questions where exam_id = ${examId}
    `;
    if (!questions.length) return { ok: false as const, error: "This exam has no questions yet." };
    let score = 0;
    let max = 0;
    const stored: Array<{ questionId: number; choice: number }> = [];
    for (const question of questions) {
      const points = question.points > 0 ? question.points : 1;
      max += points;
      const answer = data.answers.find((item) => item.questionId === question.id);
      const choice = Number.isInteger(answer?.choice) ? Number(answer?.choice) : -1;
      stored.push({ questionId: question.id, choice });
      if (choice === question.correct_index) score += points;
    }
    const passed = max > 0 && Math.round((score / max) * 100) >= exam.pass_mark;
    await sql`
      insert into exam_attempts (exam_id, user_id, answers, score, max_score, passed)
      values (${examId}, ${context.userId}, ${JSON.stringify(stored)}::jsonb, ${score}, ${max}, ${passed})
    `;
    if (passed) {
      const settings = await sql<{ auto_issue_certificates: boolean }>`
        select auto_issue_certificates from site_settings where id = 1
      `;
      if (settings[0]?.auto_issue_certificates) {
        await issueFor(context.userId, member.displayName, examId, exam.title, context.userId);
      }
    }
    return { ok: true as const, score, max, passed };
  });

export const downloadCertificate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((publicId: string) => publicId.trim().slice(0, 40))
  .handler(async ({ context, data }) => {
    const sql = await db();
    const rows = await sql<{ student_name: string; title: string; public_id: string; issued_on: string }>`
      select student_name, title, public_id, to_char(issued_at at time zone 'UTC', 'YYYY-MM-DD') as issued_on
      from certificates where public_id = ${data} and user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return { ok: false as const, error: "That certificate is not on your account." };
    const bytes = buildCertificatePdf({
      studentName: row.student_name,
      title: row.title,
      certificateId: row.public_id,
      issuedOn: row.issued_on,
    });
    return { ok: true as const, filename: `${row.public_id}.pdf`, base64: Buffer.from(bytes).toString("base64") };
  });

export const claimAdmin = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((code: string) => code)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    if (await rateLimited(`admin-code:${context.userId}`, 5, 15 * 60)) {
      return { ok: false as const, reason: "rate_limited" as const };
    }
    const member = await loadMember(context.userId);
    if (member.role === "admin") return { ok: true as const, reason: "already" as const };
    const code = data.trim();
    if (code.length < 4 || code.length > 200) return { ok: false as const, reason: "invalid" as const };
    const match = await accessCodeMatches(code);
    if (match === "unconfigured") return { ok: false as const, reason: "unconfigured" as const };
    if (!match) {
      await audit(context.userId, "admin.claim_failed", "profile", context.userId, "Rejected administrator claim");
      return { ok: false as const, reason: "invalid" as const };
    }
    const sql = await db();
    await sql`
      update profiles set role = 'admin', updated_at = now()
      where user_id = ${context.userId} and role = 'student'
    `;
    await storeAccessHash(code);
    await audit(context.userId, "admin.claim", "profile", context.userId, "Administrator access granted");
    return { ok: true as const, reason: "granted" as const };
  });

async function issueFor(userId: string, name: string, examId: number, title: string, actorId: string) {
  const sql = await db();
  const existing = await sql<{ public_id: string }>`
    select public_id from certificates where user_id = ${userId} and exam_id = ${examId}
  `;
  if (existing[0]) return existing[0].public_id;
  const { randomBytes } = await import("node:crypto");
  const publicId = `QX-${randomBytes(5).toString("hex").toUpperCase()}`;
  await sql`
    insert into certificates (public_id, user_id, exam_id, student_name, title)
    values (${publicId}, ${userId}, ${examId}, ${clip(name, 80)}, ${clip(title, 140)})
  `;
  await audit(actorId, "certificate.issue", "certificate", publicId, "Certificate issued");
  return publicId;
}

