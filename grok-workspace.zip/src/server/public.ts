import { createServerFn } from "@tanstack/react-start";
import {
  fallbackChrome,
  type Announcement,
  type Chrome,
  type CourseCard,
  type Faq,
  type Plan,
  type Showcase,
  type VideoLink,
} from "@/lib/academy";
import {
  assertSameSite,
  clientBucket,
  db,
  mapCourse,
  rateLimited,
  readChrome,
  readPlans,
} from "@/server/shared";

export const getChrome = createServerFn({ method: "GET" }).handler(async (): Promise<Chrome> => {
  try {
    return await readChrome();
  } catch (error) {
    console.error(error);
    return fallbackChrome();
  }
});

export type HomeData = {
  chrome: Chrome;
  courses: CourseCard[];
  plans: Plan[];
  faqs: Faq[];
  announcements: Announcement[];
  projects: Showcase[];
  videos: VideoLink[];
};

export const getHome = createServerFn({ method: "GET" }).handler(async (): Promise<HomeData> => {
  const chrome = await readChrome();
  const [courses, plans, faqs, announcements, projects, videos] = await Promise.all([
    publishedCourses(),
    readPlans(true),
    publishedFaqs(),
    publishedAnnouncements(6),
    publishedProjects(),
    publishedVideos(),
  ]);
  return { chrome, courses, plans, faqs, announcements, projects, videos };
});

export const getCoursePage = createServerFn({ method: "GET" })
  .validator((slug: string) => slug.trim().slice(0, 80))
  .handler(async ({ data }) => {
    const sql = await db();
    const rows = await sql<Parameters<typeof mapCourse>[0]>`
      select c.id, c.slug, c.title, c.description, c.category, c.difficulty, c.plan_code,
        c.checkout_url, c.outcomes, c.curriculum, c.cover, c.published, c.sort_order,
        (select count(*)::int from lessons l where l.course_id = c.id) as lesson_count
      from courses c
      where c.slug = ${data} and c.published = true
    `;
    return rows[0] ? mapCourse(rows[0]) : null;
  });

export const getCatalog = createServerFn({ method: "GET" }).handler(async () => {
  const [courses, plans] = await Promise.all([publishedCourses(), readPlans(true)]);
  return { courses, plans };
});

export const getCommunity = createServerFn({ method: "GET" }).handler(async () => {
  const [announcements, videos, projects] = await Promise.all([
    publishedAnnouncements(20),
    publishedVideos(),
    publishedProjects(),
  ]);
  return { announcements, videos, projects };
});

export const verifyCertificate = createServerFn({ method: "GET" })
  .validator((code: string) => code.trim().slice(0, 40))
  .handler(async ({ data }) => {
    const sql = await db();
    const rows = await sql<{
      public_id: string;
      student_name: string;
      title: string;
      issued_on: string;
    }>`
      select public_id, student_name, title, to_char(issued_at at time zone 'UTC', 'YYYY-MM-DD') as issued_on
      from certificates where public_id = ${data}
    `;
    const row = rows[0];
    if (!row) return { valid: false as const };
    return {
      valid: true as const,
      publicId: row.public_id,
      studentName: row.student_name,
      title: row.title,
      issuedOn: row.issued_on,
    };
  });

export const submitContact = createServerFn({ method: "POST" })
  .validator((input: { name: string; email: string; message: string; company: string }) => input)
  .handler(async ({ data }) => {
    await assertSameSite();
    if ((data.company ?? "").trim()) return { ok: true as const };
    const bucket = await clientBucket("contact");
    if (await rateLimited(bucket, 5, 60 * 60)) {
      return { ok: false as const, error: "Please wait a while before sending another message." };
    }
    const name = data.name.trim();
    const email = data.email.trim().toLowerCase();
    const message = data.message.trim();
    if (name.length < 2 || name.length > 80) return { ok: false as const, error: "Enter your name." };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
      return { ok: false as const, error: "Enter a valid email address." };
    }
    if (message.length < 20 || message.length > 2000) {
      return { ok: false as const, error: "Write a message of at least a few sentences." };
    }
    const sql = await db();
    await sql`
      insert into contact_messages (name, email, message) values (${name}, ${email}, ${message})
    `;
    return { ok: true as const };
  });

export const getShowcaseImage = createServerFn({ method: "GET" })
  .validator((id: number) => Number(id))
  .handler(async ({ data }) => {
    if (!Number.isInteger(data)) return null;
    const sql = await db();
    const rows = await sql<{ media_data: string | null }>`
      select media_data from submissions
      where id = ${data} and status = 'approved' and showcase = true
    `;
    return rows[0]?.media_data ?? null;
  });

async function publishedCourses(): Promise<CourseCard[]> {
  const sql = await db();
  const rows = await sql<Parameters<typeof mapCourse>[0]>`
    select c.id, c.slug, c.title, c.description, c.category, c.difficulty, c.plan_code,
      c.checkout_url, c.outcomes, c.curriculum, c.cover, c.published, c.sort_order,
      (select count(*)::int from lessons l where l.course_id = c.id) as lesson_count
    from courses c
    where c.published = true
    order by c.sort_order, c.id
  `;
  return rows.map(mapCourse);
}

async function publishedFaqs(): Promise<Faq[]> {
  const sql = await db();
  const rows = await sql<Faq & { sort_order: number }>`
    select id, question, answer, sort_order, published
    from faqs where published = true order by sort_order, id
  `;
  return rows.map((row) => ({
    id: row.id,
    question: row.question,
    answer: row.answer,
    sortOrder: row.sort_order,
    published: row.published,
  }));
}

async function publishedAnnouncements(limit: number): Promise<Announcement[]> {
  const sql = await db();
  const rows = await sql<{
    id: number;
    title: string;
    body: string;
    kind: string;
    published: boolean;
    created_on: string;
  }>`
    select id, title, body, kind, published,
      to_char(created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
    from announcements
    where published = true
    order by created_at desc
    limit ${limit}
  `;
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    body: row.body,
    kind: row.kind,
    published: row.published,
    createdOn: row.created_on,
  }));
}

async function publishedProjects(): Promise<Showcase[]> {
  const sql = await db();
  const rows = await sql<{
    id: number;
    title: string;
    description: string;
    student_name: string;
    skills: string;
    video_url: string | null;
    has_image: boolean;
    created_on: string;
  }>`
    select s.id, s.title, s.description, coalesce(p.display_name, 'Student') as student_name,
      s.skills, s.video_url, (s.media_data is not null) as has_image,
      to_char(s.created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
    from submissions s
    left join profiles p on p.user_id = s.user_id
    where s.status = 'approved' and s.showcase = true
    order by s.created_at desc
  `;
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    description: row.description,
    studentName: row.student_name,
    skills: row.skills,
    videoUrl: row.video_url,
    hasImage: row.has_image,
    createdOn: row.created_on,
  }));
}

async function publishedVideos(): Promise<VideoLink[]> {
  const sql = await db();
  const rows = await sql<{ id: number; title: string; url: string; published: boolean; sort_order: number }>`
    select id, title, url, published, sort_order
    from featured_videos where published = true order by sort_order, id
  `;
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    url: row.url,
    published: row.published,
    sortOrder: row.sort_order,
  }));
}

export async function serveBrand(asset: string): Promise<Response> {
  const { readBrand } = await import("@/server/shared");
  const column =
    asset === "logo"
      ? "logo_data"
      : asset === "icon"
        ? "favicon_data"
        : asset === "hero"
          ? "hero_image"
          : asset === "about"
            ? "about_image"
            : asset === "project"
              ? null
              : null;
  if (asset.startsWith("project-")) {
    const id = Number(asset.slice("project-".length));
    if (!Number.isInteger(id)) return new Response(null, { status: 404 });
    const sql = await db();
    const rows = await sql<{ media_data: string | null }>`
      select media_data from submissions
      where id = ${id} and status = 'approved' and showcase = true
    `;
    return imageResponse(rows[0]?.media_data ?? null);
  }
  if (!column) return new Response(null, { status: 404 });
  const data = await readBrand(column);
  if (!data && asset === "icon") {
    return new Response(null, { status: 302, headers: { Location: "/favicon.svg" } });
  }
  if (!data && asset === "hero") {
    return new Response(null, { status: 302, headers: { Location: "/media/hero.jpg" } });
  }
  if (!data && asset === "about") {
    return new Response(null, { status: 302, headers: { Location: "/media/studio.jpg" } });
  }
  return imageResponse(data);
}

function imageResponse(data: string | null): Response {
  if (!data) return new Response(null, { status: 404 });
  if (data.startsWith("/")) {
    return new Response(null, { status: 302, headers: { Location: data } });
  }
  const match = data.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return new Response(null, { status: 404 });
  const bytes = Buffer.from(match[2], "base64");
  return new Response(bytes, {
    headers: {
      "Content-Type": match[1],
      "Cache-Control": "public, max-age=300",
    },
  });
}
