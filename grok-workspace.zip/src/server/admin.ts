import { createServerFn } from "@tanstack/react-start";
import { buildCertificatePdf } from "@/lib/pdf";
import { httpsUrl, slugify, type PlanCode, type Sections } from "@/lib/academy";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  accessCodeMatches,
  assertSameSite,
  audit,
  cleanNote,
  clip,
  db,
  imageData,
  isAccent,
  isDifficulty,
  isPlan,
  isTheme,
  mapCourse,
  requireAdmin,
  storeAccessHash,
} from "@/server/shared";

const adminGate = [authMiddleware];
void adminGate;


export const getOverview = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const rows = await sql<{
      students: number;
      verified_enrollments: number;
      pending_enrollments: number;
      published_courses: number;
      submissions: number;
      pending_submissions: number;
      exam_results: number;
      certificates: number;
      unread_messages: number;
    }>`
      select
        (select count(*)::int from profiles where role = 'student') as students,
        (select count(*)::int from enrollments where status = 'verified') as verified_enrollments,
        (select count(*)::int from enrollments where status = 'pending') as pending_enrollments,
        (select count(*)::int from courses where published) as published_courses,
        (select count(*)::int from submissions) as submissions,
        (select count(*)::int from submissions where status = 'pending') as pending_submissions,
        (select count(*)::int from exam_attempts) as exam_results,
        (select count(*)::int from certificates) as certificates,
        (select count(*)::int from contact_messages where read = false) as unread_messages
    `;
    const recent = await sql<{ id: number; action: string; entity: string; detail: string | null; created_on: string }>`
      select id, action, entity, detail, to_char(created_at at time zone 'UTC', 'YYYY-MM-DD HH24:MI') as created_on
      from audit_logs order by id desc limit 8
    `;
    return { counts: rows[0], recent };
  });

export const adminListCourses = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const rows = await sql<Parameters<typeof mapCourse>[0]>`
      select c.id, c.slug, c.title, c.description, c.category, c.difficulty, c.plan_code,
        c.checkout_url, c.outcomes, c.curriculum, c.cover, c.published, c.sort_order,
        (select count(*)::int from lessons l where l.course_id = c.id) as lesson_count
      from courses c order by c.sort_order, c.id
    `;
    return rows.map(mapCourse);
  });

type CourseInput = {
  id?: number | null;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  planCode: string;
  checkoutUrl: string;
  outcomes: string;
  curriculum: string;
  published: boolean;
  cover: string;
};

export const saveCourse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CourseInput) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const title = clip(data.title, 140);
    const description = clip(data.description, 2000);
    const category = clip(data.category, 80);
    if (title.length < 3 || description.length < 10 || category.length < 2) {
      return { ok: false as const, error: "A course needs a title, category, and description." };
    }
    if (!isDifficulty(data.difficulty)) return { ok: false as const, error: "Choose a difficulty." };
    const planCode = data.planCode && isPlan(data.planCode) ? data.planCode : null;
    const checkout = data.checkoutUrl.trim() ? httpsUrl(data.checkoutUrl) : null;
    if (data.checkoutUrl.trim() && !checkout) return { ok: false as const, error: "Checkout links must use https." };
    const outcomes = data.outcomes
      .split("\n")
      .map((line) => clip(line, 180))
      .filter(Boolean)
      .slice(0, 8);
    const curriculum = clip(data.curriculum, 4000) || null;
    let cover: string | null = null;
    if (data.cover.startsWith("/media/")) cover = data.cover;
    else if (data.cover.startsWith("data:")) {
      cover = imageData(data.cover);
      if (!cover) return { ok: false as const, error: "Cover images must be JPG, PNG, or WebP and not too large." };
    }
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      const current = await sql<{ cover: string | null; slug: string }>`select cover, slug from courses where id = ${id}`;
      if (!current[0]) return { ok: false as const, error: "That course was not found." };
      const nextCover = cover ?? current[0].cover;
      await sql`
        update courses set title = ${title}, description = ${description}, category = ${category},
          difficulty = ${data.difficulty}, plan_code = ${planCode}, checkout_url = ${checkout},
          outcomes = ${JSON.stringify(outcomes)}::jsonb, curriculum = ${curriculum}, cover = ${nextCover},
          published = ${Boolean(data.published)}, updated_at = now()
        where id = ${id}
      `;
      await audit(context.userId, data.published ? "course.publish" : "course.update", "course", String(id), title);
      return { ok: true as const, id };
    }
    const slug = await uniqueSlug(title);
    const rows = await sql<{ id: number }>`
      insert into courses (slug, title, description, category, difficulty, plan_code, checkout_url, outcomes, curriculum, cover, published, sort_order)
      values (
        ${slug}, ${title}, ${description}, ${category}, ${data.difficulty}, ${planCode}, ${checkout},
        ${JSON.stringify(outcomes)}::jsonb, ${curriculum}, ${cover}, ${Boolean(data.published)},
        (select coalesce(max(sort_order), 0) + 1 from courses)
      )
      returning id
    `;
    await audit(context.userId, "course.create", "course", String(rows[0]?.id ?? ""), title);
    return { ok: true as const, id: rows[0]?.id ?? 0 };
  });

export const deleteCourse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from courses where id = ${data}`;
    await audit(context.userId, "course.delete", "course", String(data), "Course deleted");
    return { ok: true as const };
  });

export const moveCourse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; direction: "up" | "down" }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    const rows = await sql<{ id: number; sort_order: number }>`select id, sort_order from courses order by sort_order, id`;
    const index = rows.findIndex((row) => row.id === Number(data.id));
    const swapWith = data.direction === "up" ? index - 1 : index + 1;
    if (index < 0 || swapWith < 0 || swapWith >= rows.length) return { ok: true as const };
    const a = rows[index];
    const b = rows[swapWith];
    await sql`update courses set sort_order = ${b.sort_order} where id = ${a.id}`;
    await sql`update courses set sort_order = ${a.sort_order} where id = ${b.id}`;
    if (a.sort_order === b.sort_order) {
      await sql`update courses set sort_order = ${a.sort_order + (data.direction === "up" ? -1 : 1)} where id = ${a.id}`;
    }
    await audit(context.userId, "course.reorder", "course", String(a.id), "Course order changed");
    return { ok: true as const };
  });

export const adminLessons = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((courseId: number) => Number(courseId))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; title: string; body: string; material_url: string | null; sort_order: number }>`
      select id, title, body, material_url, sort_order from lessons
      where course_id = ${data} order by sort_order, id
    `;
  });

export const saveLesson = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; courseId: number; title: string; body: string; materialUrl: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const title = clip(data.title, 140);
    const body = clip(data.body, 8000);
    if (title.length < 2) return { ok: false as const, error: "A lesson needs a title." };
    const material = data.materialUrl.trim() ? httpsUrl(data.materialUrl) : null;
    if (data.materialUrl.trim() && !material) return { ok: false as const, error: "Material links must use https." };
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      await sql`
        update lessons set title = ${title}, body = ${body}, material_url = ${material}
        where id = ${id} and course_id = ${Number(data.courseId)}
      `;
    } else {
      await sql`
        insert into lessons (course_id, title, body, material_url, sort_order)
        values (${Number(data.courseId)}, ${title}, ${body}, ${material},
          (select coalesce(max(sort_order), 0) + 1 from lessons where course_id = ${Number(data.courseId)}))
      `;
    }
    await audit(context.userId, "lesson.save", "course", String(data.courseId), title);
    return { ok: true as const };
  });

export const deleteLesson = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from lessons where id = ${data}`;
    await audit(context.userId, "lesson.delete", "lesson", String(data), "Lesson deleted");
    return { ok: true as const };
  });

export const adminStudents = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ user_id: string; display_name: string; email: string; role: string; status: string; created_on: string }>`
      select p.user_id, p.display_name, u.email, p.role, p.status,
        to_char(p.created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from profiles p
      join "user" u on u.id = p.user_id
      order by p.created_at desc
    `;
  });

export const setStudentStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; status: "active" | "suspended" }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    if (data.userId === context.userId) return { ok: false as const, error: "You cannot suspend your own account here." };
    if (data.status !== "active" && data.status !== "suspended") return { ok: false as const, error: "Unknown status." };
    const sql = await db();
    await sql`
      update profiles set status = ${data.status}, updated_at = now()
      where user_id = ${data.userId} and role = 'student'
    `;
    await audit(context.userId, "student.status", "profile", data.userId, data.status);
    return { ok: true as const };
  });

export const adminEnrollments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{
      id: number;
      user_id: string;
      display_name: string;
      email: string;
      plan_code: string | null;
      course_title: string | null;
      status: string;
      source: string;
      note: string | null;
      created_on: string;
    }>`
      select e.id, e.user_id, p.display_name, u.email, e.plan_code, c.title as course_title,
        e.status, e.source, e.note, to_char(e.created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from enrollments e
      join profiles p on p.user_id = e.user_id
      join "user" u on u.id = e.user_id
      left join courses c on c.id = e.course_id
      order by e.created_at desc
      limit 200
    `;
  });

export const setEnrollmentStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: "verified" | "revoked" | "pending"; note: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    if (!["verified", "revoked", "pending"].includes(data.status)) return { ok: false as const, error: "Unknown status." };
    const note = cleanNote(data.note || "");
    const sql = await db();
    if (data.status === "verified") {
      await sql`
        update enrollments set status = 'verified', note = ${note || null},
          verified_by = ${context.userId}, verified_at = now()
        where id = ${Number(data.id)}
      `;
    } else {
      await sql`
        update enrollments set status = ${data.status}, note = ${note || null},
          verified_by = null, verified_at = null
        where id = ${Number(data.id)}
      `;
    }
    await audit(context.userId, "enrollment.update", "enrollment", String(data.id), data.status);
    return { ok: true as const };
  });

export const createEnrollment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; planCode: string; courseId: number | null; note: string; verified: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const planCode = data.planCode && isPlan(data.planCode) ? data.planCode : null;
    const courseId = Number.isInteger(Number(data.courseId)) && Number(data.courseId) > 0 ? Number(data.courseId) : null;
    if (!planCode && !courseId) return { ok: false as const, error: "Choose a plan or a course." };
    const note = cleanNote(data.note || "Recorded by an administrator. Card details are not stored.");
    const sql = await db();
    const student = await sql<{ user_id: string }>`select user_id from profiles where user_id = ${data.userId}`;
    if (!student[0]) return { ok: false as const, error: "That student was not found." };
    await sql`
      insert into enrollments (user_id, course_id, plan_code, status, source, note, verified_by, verified_at)
      values (
        ${data.userId}, ${courseId}, ${planCode}, ${data.verified ? "verified" : "pending"}, 'admin', ${note},
        ${data.verified ? context.userId : null}, ${data.verified ? new Date().toISOString() : null}
      )
    `;
    await audit(context.userId, "enrollment.create", "enrollment", data.userId, data.verified ? "verified" : "pending");
    return { ok: true as const };
  });

export const adminSubmissions = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{
      id: number;
      user_id: string;
      display_name: string;
      title: string;
      description: string;
      skills: string;
      video_url: string | null;
      has_image: boolean;
      status: string;
      showcase: boolean;
      admin_note: string | null;
      created_on: string;
    }>`
      select s.id, s.user_id, coalesce(p.display_name, 'Student') as display_name, s.title, s.description,
        s.skills, s.video_url, (s.media_data is not null) as has_image, s.status, s.showcase, s.admin_note,
        to_char(s.created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from submissions s
      left join profiles p on p.user_id = s.user_id
      order by s.created_at desc
      limit 200
    `;
  });

export const reviewSubmission = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: "pending" | "approved" | "rejected"; showcase: boolean; note: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const showcase = data.status === "approved" && Boolean(data.showcase);
    const sql = await db();
    await sql`
      update submissions set status = ${data.status}, showcase = ${showcase}, admin_note = ${clip(data.note, 500) || null}
      where id = ${Number(data.id)}
    `;
    await audit(context.userId, "submission.review", "submission", String(data.id), `${data.status}${showcase ? " featured" : ""}`);
    return { ok: true as const };
  });

export const adminSubmissionImage = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const rows = await sql<{ media_data: string | null }>`select media_data from submissions where id = ${data}`;
    return rows[0]?.media_data ?? null;
  });

export const adminAnnouncements = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; title: string; body: string; kind: string; published: boolean; created_on: string }>`
      select id, title, body, kind, published, to_char(created_at at time zone 'UTC', 'YYYY-MM-DD') as created_on
      from announcements order by created_at desc
    `;
  });

export const saveAnnouncement = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; title: string; body: string; kind: string; published: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const title = clip(data.title, 140);
    const body = clip(data.body, 4000);
    const kind = ["news", "class", "bootcamp", "notice"].includes(data.kind) ? data.kind : "news";
    if (title.length < 3 || body.length < 5) return { ok: false as const, error: "Add a title and a message." };
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      await sql`update announcements set title = ${title}, body = ${body}, kind = ${kind}, published = ${Boolean(data.published)} where id = ${id}`;
    } else {
      await sql`insert into announcements (title, body, kind, published) values (${title}, ${body}, ${kind}, ${Boolean(data.published)})`;
    }
    await audit(context.userId, "announcement.save", "announcement", title, data.published ? "published" : "draft");
    return { ok: true as const };
  });

export const deleteAnnouncement = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from announcements where id = ${data}`;
    await audit(context.userId, "announcement.delete", "announcement", String(data), "Announcement removed");
    return { ok: true as const };
  });

export const adminVideos = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; title: string; url: string; published: boolean; sort_order: number }>`
      select id, title, url, published, sort_order from featured_videos order by sort_order, id
    `;
  });

export const saveVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; title: string; url: string; published: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const url = httpsUrl(data.url);
    const title = clip(data.title, 140);
    if (!url || title.length < 2) return { ok: false as const, error: "Add a title and an https video link." };
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      await sql`update featured_videos set title = ${title}, url = ${url}, published = ${Boolean(data.published)} where id = ${id}`;
    } else {
      await sql`insert into featured_videos (title, url, published, sort_order) values (${title}, ${url}, ${Boolean(data.published)}, (select coalesce(max(sort_order), 0) + 1 from featured_videos))`;
    }
    await audit(context.userId, "video.save", "video", title, "Featured video saved");
    return { ok: true as const };
  });

export const deleteVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from featured_videos where id = ${data}`;
    return { ok: true as const };
  });

export const adminFaqs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; question: string; answer: string; sort_order: number; published: boolean }>`
      select id, question, answer, sort_order, published from faqs order by sort_order, id
    `;
  });

export const saveFaq = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; question: string; answer: string; published: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const question = clip(data.question, 200);
    const answer = clip(data.answer, 2000);
    if (question.length < 5 || answer.length < 5) return { ok: false as const, error: "Add a question and an answer." };
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      await sql`update faqs set question = ${question}, answer = ${answer}, published = ${Boolean(data.published)} where id = ${id}`;
    } else {
      await sql`insert into faqs (question, answer, published, sort_order) values (${question}, ${answer}, ${Boolean(data.published)}, (select coalesce(max(sort_order), 0) + 1 from faqs))`;
    }
    await audit(context.userId, "faq.save", "faq", question, "FAQ saved");
    return { ok: true as const };
  });

export const deleteFaq = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from faqs where id = ${data}`;
    return { ok: true as const };
  });

export const adminPlans = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const { readPlans } = await import("@/server/shared");
    return readPlans(false);
  });

export const savePlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { code: string; name: string; priceNgn: number; description: string; features: string; checkoutUrl: string; published: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    if (!isPlan(data.code)) return { ok: false as const, error: "Unknown plan." };
    const checkout = httpsUrl(data.checkoutUrl);
    if (!checkout) return { ok: false as const, error: "The Selar link must use https." };
    const price = Math.round(Number(data.priceNgn));
    if (!Number.isFinite(price) || price < 0 || price > 50_000_000) return { ok: false as const, error: "Enter a valid price in naira." };
    const features = data.features.split("\n").map((line) => clip(line, 180)).filter(Boolean).slice(0, 8);
    const sql = await db();
    await sql`
      update plans set name = ${clip(data.name, 40)}, price_ngn = ${price}, description = ${clip(data.description, 500)},
        features = ${JSON.stringify(features)}::jsonb, checkout_url = ${checkout}, published = ${Boolean(data.published)}
      where code = ${data.code}
    `;
    await audit(context.userId, "plan.update", "plan", data.code, "Plan updated");
    return { ok: true as const };
  });

export const saveContent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    heroKicker: string;
    heroTitle: string;
    heroBody: string;
    aboutTitle: string;
    aboutBody: string;
    founderNote: string;
    contactEmail: string;
    contactNote: string;
    sections: Sections;
    autoIssueCertificates: boolean;
  }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const email = data.contactEmail.trim().toLowerCase();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false as const, error: "That contact email does not look valid." };
    const sql = await db();
    await sql`
      update site_settings set
        hero_kicker = ${clip(data.heroKicker, 120)},
        hero_title = ${clip(data.heroTitle, 180)},
        hero_body = ${clip(data.heroBody, 800)},
        about_title = ${clip(data.aboutTitle, 160)},
        about_body = ${clip(data.aboutBody, 2000)},
        founder_note = ${clip(data.founderNote, 800)},
        contact_email = ${email || null},
        contact_note = ${clip(data.contactNote, 500)},
        sections = ${JSON.stringify(data.sections)}::jsonb,
        auto_issue_certificates = ${Boolean(data.autoIssueCertificates)},
        updated_at = now()
      where id = 1
    `;
    await audit(context.userId, "content.update", "settings", "1", "Homepage content updated");
    return { ok: true as const };
  });

export const saveBrand = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    themeMode: string;
    accent: string;
    youtubeUrl: string;
    whatsappUrl: string;
    facebookUrl: string;
    instagramUrl: string;
    tiktokUrl: string;
    xUrl: string;
    linkedinUrl: string;
    showHeaderSocial: boolean;
    showFooterSocial: boolean;
    logo: string;
    clearLogo: boolean;
    hero: string;
    clearHero: boolean;
    about: string;
    clearAbout: boolean;
    icon: string;
    clearIcon: boolean;
  }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    if (!isTheme(data.themeMode) || !isAccent(data.accent)) return { ok: false as const, error: "Choose a theme and an accent." };
    const youtube = httpsUrl(data.youtubeUrl);
    const whatsapp = httpsUrl(data.whatsappUrl);
    if (!youtube || !whatsapp) return { ok: false as const, error: "YouTube and WhatsApp links must use https." };
    const optional = (value: string) => {
      if (!value.trim()) return null;
      const url = httpsUrl(value);
      if (!url) throw new Error("Social links must use https, or be left empty.");
      return url;
    };
    let facebook: string | null, instagram: string | null, tiktok: string | null, x: string | null, linkedin: string | null;
    try {
      facebook = optional(data.facebookUrl);
      instagram = optional(data.instagramUrl);
      tiktok = optional(data.tiktokUrl);
      x = optional(data.xUrl);
      linkedin = optional(data.linkedinUrl);
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : "Check the social links." };
    }
    const logo = data.logo ? imageData(data.logo) : null;
    const hero = data.hero ? imageData(data.hero) : null;
    const about = data.about ? imageData(data.about) : null;
    const icon = data.icon ? imageData(data.icon) : null;
    if ((data.logo && !logo) || (data.hero && !hero) || (data.about && !about) || (data.icon && !icon)) {
      return { ok: false as const, error: "Images must be JPG, PNG, or WebP and not too large." };
    }
    const sql = await db();
    await sql`
      update site_settings set
        theme_mode = ${data.themeMode},
        accent = ${data.accent},
        youtube_url = ${youtube},
        whatsapp_url = ${whatsapp},
        facebook_url = ${facebook},
        instagram_url = ${instagram},
        tiktok_url = ${tiktok},
        x_url = ${x},
        linkedin_url = ${linkedin},
        show_header_social = ${Boolean(data.showHeaderSocial)},
        show_footer_social = ${Boolean(data.showFooterSocial)},
        logo_data = case when ${data.clearLogo} then null when ${logo}::text is not null then ${logo} else logo_data end,
        hero_image = case when ${data.clearHero} then null when ${hero}::text is not null then ${hero} else hero_image end,
        about_image = case when ${data.clearAbout} then null when ${about}::text is not null then ${about} else about_image end,
        favicon_data = case when ${data.clearIcon} then null when ${icon}::text is not null then ${icon} else favicon_data end,
        updated_at = now()
      where id = 1
    `;
    await audit(context.userId, "brand.update", "settings", "1", "Brand settings updated");
    return { ok: true as const };
  });

export const saveSeo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { seoTitle: string; seoDescription: string; canonicalUrl: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const canonical = httpsUrl(data.canonicalUrl);
    if (!canonical) return { ok: false as const, error: "The canonical URL must use https." };
    const sql = await db();
    await sql`
      update site_settings set seo_title = ${clip(data.seoTitle, 140)},
        seo_description = ${clip(data.seoDescription, 300)},
        canonical_url = ${canonical.replace(/\/$/, "")},
        updated_at = now()
      where id = 1
    `;
    await audit(context.userId, "seo.update", "settings", "1", "SEO settings updated");
    return { ok: true as const };
  });

export const adminMessages = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; name: string; email: string; message: string; read: boolean; created_on: string }>`
      select id, name, email, message, read, to_char(created_at at time zone 'UTC', 'YYYY-MM-DD HH24:MI') as created_on
      from contact_messages order by created_at desc limit 100
    `;
  });

export const markMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`update contact_messages set read = true where id = ${data}`;
    return { ok: true as const };
  });

export const adminAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    return sql<{ id: number; action: string; entity: string; entity_id: string | null; detail: string | null; created_on: string }>`
      select id, action, entity, entity_id, detail, to_char(created_at at time zone 'UTC', 'YYYY-MM-DD HH24:MI') as created_on
      from audit_logs order by id desc limit 150
    `;
  });

export const adminExams = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const exams = await sql<{
      id: number;
      title: string;
      instructions: string;
      course_id: number | null;
      pass_mark: number;
      deadline: string | null;
      published: boolean;
    }>`
      select id, title, instructions, course_id, pass_mark,
        to_char(deadline at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI') as deadline,
        published
      from exams order by id desc
    `;
    const questions = (await sql<{
      id: number;
      exam_id: number;
      prompt: string;
      options: unknown;
      correct_index: number;
      points: number;
    }>`
      select id, exam_id, prompt, options, correct_index, points from exam_questions order by sort_order, id
    `).map((question) => ({
      id: question.id,
      exam_id: question.exam_id,
      prompt: question.prompt,
      options: (Array.isArray(question.options) ? question.options : []).map((option) => String(option)),
      correct_index: question.correct_index,
      points: question.points,
    }));
    const attempts = await sql<{ exam_id: number; user_id: string; display_name: string; score: number; max_score: number; passed: boolean }>`
      select a.exam_id, a.user_id, coalesce(p.display_name, 'Student') as display_name, a.score, a.max_score, a.passed
      from exam_attempts a
      left join profiles p on p.user_id = a.user_id
      order by a.submitted_at desc
    `;
    return { exams, questions, attempts };
  });

export const saveExam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; title: string; instructions: string; courseId: number | null; passMark: number; deadline: string; published: boolean }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const title = clip(data.title, 140);
    if (title.length < 3) return { ok: false as const, error: "Name the exam." };
    const pass = Math.round(Number(data.passMark));
    if (pass < 1 || pass > 100) return { ok: false as const, error: "Pass mark must be between 1 and 100." };
    const deadline = data.deadline.trim() ? new Date(data.deadline.trim() + "Z") : null;
    if (data.deadline.trim() && Number.isNaN(deadline?.getTime())) return { ok: false as const, error: "That deadline is not valid." };
    const courseId = Number(data.courseId) > 0 ? Number(data.courseId) : null;
    const published = Boolean(data.published);
    const sql = await db();
    const id = Number(data.id);
    let examId = id;
    if (Number.isInteger(id) && id > 0) {
      await sql`
        update exams set title = ${title}, instructions = ${clip(data.instructions, 2000)}, course_id = ${courseId},
          pass_mark = ${pass}, deadline = ${deadline ? deadline.toISOString() : null}, published = false
        where id = ${id}
      `;
    } else {
      const rows = await sql<{ id: number }>`
        insert into exams (title, instructions, course_id, pass_mark, deadline, published)
        values (${title}, ${clip(data.instructions, 2000)}, ${courseId}, ${pass}, ${deadline ? deadline.toISOString() : null}, false)
        returning id
      `;
      examId = rows[0]?.id ?? 0;
    }
    if (published) {
      const count = await sql<{ n: number }>`select count(*)::int as n from exam_questions where exam_id = ${examId}`;
      if (!count[0]?.n) return { ok: false as const, error: "Add at least one question before publishing." };
      await sql`update exams set published = true where id = ${examId}`;
    }
    await audit(context.userId, "exam.save", "exam", String(examId), title);
    return { ok: true as const, id: examId };
  });

export const saveQuestion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: number | null; examId: number; prompt: string; options: string; correctIndex: number; points: number }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const options = data.options.split("\n").map((line) => clip(line, 240)).filter(Boolean).slice(0, 6);
    const prompt = clip(data.prompt, 500);
    if (prompt.length < 3 || options.length < 2) return { ok: false as const, error: "Add a question and at least two options, one per line." };
    const correct = Number(data.correctIndex);
    if (correct < 0 || correct >= options.length) return { ok: false as const, error: "Choose which option is correct." };
    const points = Math.min(20, Math.max(1, Math.round(Number(data.points) || 1)));
    const sql = await db();
    const id = Number(data.id);
    if (Number.isInteger(id) && id > 0) {
      await sql`
        update exam_questions set prompt = ${prompt}, options = ${JSON.stringify(options)}::jsonb,
          correct_index = ${correct}, points = ${points}
        where id = ${id} and exam_id = ${Number(data.examId)}
      `;
    } else {
      await sql`
        insert into exam_questions (exam_id, prompt, options, correct_index, points, sort_order)
        values (${Number(data.examId)}, ${prompt}, ${JSON.stringify(options)}::jsonb, ${correct}, ${points},
          (select coalesce(max(sort_order), 0) + 1 from exam_questions where exam_id = ${Number(data.examId)}))
      `;
    }
    await audit(context.userId, "exam.question", "exam", String(data.examId), "Question saved");
    return { ok: true as const };
  });

export const deleteQuestion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => Number(id))
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from exam_questions where id = ${data}`;
    return { ok: true as const };
  });

export const resetAttempt = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { examId: number; userId: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    await sql`delete from exam_attempts where exam_id = ${Number(data.examId)} and user_id = ${data.userId}`;
    await audit(context.userId, "exam.reset", "exam", String(data.examId), "Attempt removed");
    return { ok: true as const };
  });

export const adminCertificates = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const issued = await sql<{ public_id: string; student_name: string; title: string; user_id: string; issued_on: string }>`
      select public_id, student_name, title, user_id, to_char(issued_at at time zone 'UTC', 'YYYY-MM-DD') as issued_on
      from certificates order by issued_at desc
    `;
    const eligible = await sql<{ user_id: string; display_name: string; exam_id: number; exam_title: string; score: number; max_score: number }>`
      select a.user_id, coalesce(p.display_name, 'Student') as display_name, a.exam_id, e.title as exam_title, a.score, a.max_score
      from exam_attempts a
      join exams e on e.id = a.exam_id
      left join profiles p on p.user_id = a.user_id
      where a.passed = true
        and not exists (select 1 from certificates c where c.user_id = a.user_id and c.exam_id = a.exam_id)
      order by a.submitted_at desc
    `;
    return { issued, eligible };
  });

export const issueCertificate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; examId: number; studentName: string; title: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    const sql = await db();
    const passed = await sql<{ ok: boolean }>`
      select exists (
        select 1 from exam_attempts
        where user_id = ${data.userId} and exam_id = ${Number(data.examId)} and passed = true
      ) as ok
    `;
    if (!passed[0]?.ok) return { ok: false as const, error: "That student does not have a passing result for this exam." };
    const existing = await sql<{ public_id: string }>`
      select public_id from certificates where user_id = ${data.userId} and exam_id = ${Number(data.examId)}
    `;
    if (existing[0]) return { ok: true as const, publicId: existing[0].public_id };
    const { randomBytes } = await import("node:crypto");
    const publicId = `QX-${randomBytes(5).toString("hex").toUpperCase()}`;
    const name = clip(data.studentName, 80);
    const title = clip(data.title, 140);
    if (name.length < 2 || title.length < 2) return { ok: false as const, error: "Add the name and title to print." };
    await sql`
      insert into certificates (public_id, user_id, exam_id, student_name, title)
      values (${publicId}, ${data.userId}, ${Number(data.examId)}, ${name}, ${title})
    `;
    await audit(context.userId, "certificate.issue", "certificate", publicId, title);
    return { ok: true as const, publicId };
  });

export const adminCertificatePdf = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((publicId: string) => publicId.trim().slice(0, 40))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await db();
    const rows = await sql<{ student_name: string; title: string; public_id: string; issued_on: string }>`
      select student_name, title, public_id, to_char(issued_at at time zone 'UTC', 'YYYY-MM-DD') as issued_on
      from certificates where public_id = ${data}
    `;
    const row = rows[0];
    if (!row) return { ok: false as const, error: "Certificate not found." };
    const bytes = buildCertificatePdf({
      studentName: row.student_name,
      title: row.title,
      certificateId: row.public_id,
      issuedOn: row.issued_on,
    });
    return { ok: true as const, filename: `${row.public_id}.pdf`, base64: Buffer.from(bytes).toString("base64") };
  });

export const rotateAccessCode = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { current: string; next: string }) => input)
  .handler(async ({ context, data }) => {
    await assertSameSite();
    await requireAdmin(context.userId);
    if (await (await import("@/server/shared")).rateLimited(`rotate:${context.userId}`, 5, 15 * 60)) {
      return { ok: false as const, error: "Too many attempts. Wait and try again." };
    }
    const match = await accessCodeMatches(data.current.trim());
    if (match !== true) return { ok: false as const, error: "The current access code was not accepted." };
    const next = data.next.trim();
    if (next.length < 8 || next.length > 200) return { ok: false as const, error: "The new code must be at least 8 characters." };
    await storeAccessHash(next);
    await audit(context.userId, "credential.rotate", "settings", "admin", "Administrator access code changed");
    return { ok: true as const };
  });

async function uniqueSlug(title: string): Promise<string> {
  const sql = await db();
  const base = slugify(title) || "course";
  let slug = base;
  let n = 1;
  while (true) {
    const rows = await sql<{ id: number }>`select id from courses where slug = ${slug}`;
    if (!rows[0]) return slug;
    n += 1;
    slug = `${base}-${n}`;
  }
}

export type { PlanCode };
