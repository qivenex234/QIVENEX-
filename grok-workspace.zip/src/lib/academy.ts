export const OFFICIAL = {
  site: "https://qivenexaiacademy.lovable.app",
  youtube: "https://www.youtube.com/@qivenexacademy",
  whatsapp: "https://whatsapp.com/channel/0029Vb8lkx0AzNbozwWJd12x",
  selar: {
    starter: "https://selar.com/5e16655d91",
    basic: "https://selar.com/716p7u4a6b",
    standard: "https://selar.com/4d167101ig",
  },
} as const;

export type ThemeMode = "system" | "light" | "dark";
export type Accent = "gold" | "blue" | "violet";
export type Difficulty = "beginner" | "intermediate" | "advanced";
export type PlanCode = "starter" | "basic" | "standard";
export type SectionKey =
  | "about"
  | "courses"
  | "pricing"
  | "projects"
  | "community"
  | "faq"
  | "contact";

export type Sections = Record<SectionKey, boolean>;

export type SocialKey =
  | "youtube"
  | "whatsapp"
  | "facebook"
  | "instagram"
  | "tiktok"
  | "x"
  | "linkedin";

export type Chrome = {
  heroKicker: string;
  heroTitle: string;
  heroBody: string;
  aboutTitle: string;
  aboutBody: string;
  founderNote: string;
  contactEmail: string | null;
  contactNote: string;
  seoTitle: string;
  seoDescription: string;
  canonicalUrl: string;
  themeMode: ThemeMode;
  accent: Accent;
  youtubeUrl: string;
  whatsappUrl: string;
  facebookUrl: string | null;
  instagramUrl: string | null;
  tiktokUrl: string | null;
  xUrl: string | null;
  linkedinUrl: string | null;
  showHeaderSocial: boolean;
  showFooterSocial: boolean;
  sections: Sections;
  hasLogo: boolean;
  hasCustomHero: boolean;
  hasCustomAbout: boolean;
  autoIssueCertificates: boolean;
};

export type CourseCard = {
  id: number;
  slug: string;
  title: string;
  description: string;
  category: string;
  difficulty: Difficulty;
  planCode: PlanCode | null;
  checkoutUrl: string | null;
  outcomes: string[];
  curriculum: string | null;
  cover: string | null;
  published: boolean;
  sortOrder: number;
  lessonCount: number;
};

export type Plan = {
  code: PlanCode;
  name: string;
  priceNgn: number;
  description: string;
  features: string[];
  checkoutUrl: string;
  published: boolean;
  sortOrder: number;
};

export type Faq = { id: number; question: string; answer: string; sortOrder: number; published: boolean };
export type Announcement = {
  id: number;
  title: string;
  body: string;
  kind: string;
  published: boolean;
  createdOn: string;
};
export type VideoLink = { id: number; title: string; url: string; published: boolean; sortOrder: number };
export type Showcase = {
  id: number;
  title: string;
  description: string;
  studentName: string;
  skills: string;
  videoUrl: string | null;
  hasImage: boolean;
  createdOn: string;
};

export type SocialLink = { id: SocialKey; label: string; href: string };

export function formatNaira(amount: number): string {
  const n = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `₦${n.toLocaleString("en-NG")}`;
}

export function planRank(code: string | null | undefined): number {
  if (code === "starter") return 1;
  if (code === "basic") return 2;
  if (code === "standard") return 3;
  return 0;
}

export function httpsUrl(value: string | null | undefined): string | null {
  const raw = (value ?? "").trim();
  if (!raw) return null;
  try {
    const url = new URL(raw);
    if (url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 72);
}

export function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((item) => String(item)).filter(Boolean);
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as unknown;
      if (Array.isArray(parsed)) return parsed.map((item) => String(item)).filter(Boolean);
    } catch {
      return [];
    }
  }
  return [];
}

export function asSections(value: unknown): Sections {
  const fallback: Sections = {
    about: true,
    courses: true,
    pricing: true,
    projects: true,
    community: true,
    faq: true,
    contact: true,
  };
  const source = typeof value === "string" ? safeParse(value) : value;
  if (!source || typeof source !== "object") return fallback;
  const record = source as Record<string, unknown>;
  (Object.keys(fallback) as SectionKey[]).forEach((key) => {
    if (typeof record[key] === "boolean") fallback[key] = record[key];
  });
  return fallback;
}

function safeParse(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

export function socialLinks(chrome: Chrome): SocialLink[] {
  const rows: Array<[SocialKey, string, string | null]> = [
    ["youtube", "YouTube", chrome.youtubeUrl],
    ["whatsapp", "WhatsApp", chrome.whatsappUrl],
    ["facebook", "Facebook", chrome.facebookUrl],
    ["instagram", "Instagram", chrome.instagramUrl],
    ["tiktok", "TikTok", chrome.tiktokUrl],
    ["x", "X", chrome.xUrl],
    ["linkedin", "LinkedIn", chrome.linkedinUrl],
  ];
  return rows.flatMap(([id, label, href]) => (href ? [{ id, label, href }] : []));
}

export function difficultyLabel(value: Difficulty): string {
  if (value === "beginner") return "Beginner";
  if (value === "intermediate") return "Intermediate";
  return "Advanced";
}

export const DEFAULT_SECTIONS: Sections = {
  about: true,
  courses: true,
  pricing: true,
  projects: true,
  community: true,
  faq: true,
  contact: true,
};

export function fallbackChrome(): Chrome {
  return {
    heroKicker: "Welcome to QIVENEX AI ACADEMY",
    heroTitle: "Learn AI. Build Your Ideas. Create Your Future.",
    heroBody:
      "Learn practical AI skills, create digital content, build applications and websites, and turn your knowledge into useful digital products. QIVENEX AI ACADEMY gives you a place to learn, practise, and grow—one skill at a time.",
    aboutTitle: "A practical place to learn AI",
    aboutBody:
      "QIVENEX AI ACADEMY focuses on practical, accessible AI education. You learn by doing, follow guided projects, build skills step by step, and work alongside a community that is also making useful digital products.",
    founderNote:
      "Chris Vincent is the founder of QIVENEX AI ACADEMY. Qualifications, awards, and employment history are not listed here unless he publishes them.",
    contactEmail: null,
    contactNote:
      "Send a message with the form. The academy replies from the inbox in the admin dashboard. No phone number is published on this website.",
    seoTitle: "QIVENEX AI ACADEMY",
    seoDescription:
      "QIVENEX AI ACADEMY, founded by Chris Vincent, teaches practical AI skills for beginners and entrepreneurs.",
    canonicalUrl: OFFICIAL.site,
    themeMode: "system",
    accent: "gold",
    youtubeUrl: OFFICIAL.youtube,
    whatsappUrl: OFFICIAL.whatsapp,
    facebookUrl: null,
    instagramUrl: null,
    tiktokUrl: null,
    xUrl: null,
    linkedinUrl: null,
    showHeaderSocial: true,
    showFooterSocial: true,
    sections: DEFAULT_SECTIONS,
    hasLogo: false,
    hasCustomHero: false,
    hasCustomAbout: false,
    autoIssueCertificates: false,
  };
}
