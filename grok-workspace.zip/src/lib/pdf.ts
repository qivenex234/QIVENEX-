function pdfText(value: string): string {
  const clean = value
    .normalize("NFKD")
    .replace(/[^\x20-\x7E]/g, "")
    .slice(0, 140);
  return clean.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function line(font: "F1" | "F2", size: number, x: number, y: number, text: string, color = "0.12 0.10 0.08"): string {
  return `BT\n${color} rg\n/${font} ${size} Tf\n1 0 0 1 ${x} ${y} Tm\n(${pdfText(text)}) Tj\nET\n`;
}

export function buildCertificatePdf(input: {
  studentName: string;
  title: string;
  certificateId: string;
  issuedOn: string;
}): Uint8Array {
  const stream = [
    "0.66 0.52 0.25 RG",
    "1.4 w",
    "28 28 786 539 re S",
    "0.4 w",
    "40 40 762 515 re S",
    line("F1", 13, 70, 500, "QIVENEX AI ACADEMY"),
    line("F2", 11, 70, 478, "CERTIFICATE", "0.42 0.33 0.16"),
    line("F1", 28, 70, 430, "Certificate of completion"),
    line("F2", 12, 70, 380, "This confirms that"),
    line("F1", 22, 70, 346, input.studentName || "Student"),
    line("F2", 12, 70, 300, "met the published requirement for"),
    line("F1", 16, 70, 270, input.title || "Academy assessment"),
    line("F2", 11, 70, 180, `Issued ${input.issuedOn}`),
    line("F2", 11, 70, 160, `Certificate ID ${input.certificateId}`),
    line("F2", 11, 70, 120, "Founder, Chris Vincent"),
    line("F2", 10, 70, 78, "Verify this identifier on the academy website. It is not proof of payment."),
  ].join("\n");

  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Contents 6 0 R /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
  ];

  let body = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(body.length);
    body += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = body.length;
  body += `xref\n0 ${objects.length + 1}\n`;
  body += "0000000000 65535 f \n";
  for (let i = 1; i < offsets.length; i += 1) {
    body += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  body += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new TextEncoder().encode(body);
}
