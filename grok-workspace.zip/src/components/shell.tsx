import { Link, useMatches, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { fallbackChrome, socialLinks, type Chrome, type SocialKey } from "@/lib/academy";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { UserButton } from "@/lib/auth/gates";
import { getMyAccess } from "@/server/student";

const NAV = [
  { to: "/courses", label: "Courses" },
  { to: "/projects", label: "Projects" },
  { to: "/community", label: "Community" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
] as const;

export function useChrome(): Chrome {
  const matches = useMatches();
  const data = matches[0]?.loaderData as Chrome | undefined;
  return data ?? fallbackChrome();
}

export function Shell({ children }: { children: ReactNode }) {
  const chrome = useChrome();
  const path = useRouterState({ select: (state) => state.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState<string | null>(null);
  const [theme, setTheme] = useState("system");

  useEffect(() => {
    setOpen(false);
  }, [path]);

  useEffect(() => {
    document.documentElement.dataset.accent = chrome.accent;
    const stored = window.localStorage.getItem("qivenex-theme");
    const mode = stored === "light" || stored === "dark" || stored === "system" ? stored : chrome.themeMode;
    setTheme(mode);
    if (mode === "light" || mode === "dark") document.documentElement.dataset.theme = mode;
    else delete document.documentElement.dataset.theme;
  }, [chrome.accent, chrome.themeMode]);

  useEffect(() => {
    if (!user?.id) {
      setRole(null);
      return;
    }
    let cancelled = false;
    getMyAccess()
      .then((access) => {
        if (!cancelled) setRole(access.role);
      })
      .catch(() => {
        if (!cancelled) setRole(null);
      });
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  function cycleTheme() {
    const next = theme === "system" ? "light" : theme === "light" ? "dark" : "system";
    window.localStorage.setItem("qivenex-theme", next);
    setTheme(next);
    if (next === "system") delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = next;
  }

  const links = socialLinks(chrome);

  return (
    <div className="min-h-screen">
      <a href="#content" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-fg focus:px-4 focus:py-2 focus:text-bg">
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex min-h-11 items-center gap-2">
            {chrome.hasLogo ? (
              <img src="/brand/logo" alt="" className="h-10 w-10 rounded-xl object-cover" />
            ) : (
              <Monogram />
            )}
            <span className="leading-tight">
              <span className="block font-display text-base">QIVENEX</span>
              <span className="block text-xs tracking-widest text-muted">AI ACADEMY</span>
            </span>
          </Link>
          <nav className="ml-auto hidden items-center gap-1 md:flex" aria-label="Primary">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={`rounded-full px-3 py-2 text-sm ${path.startsWith(item.to) ? "bg-paper text-fg" : "text-muted hover:text-fg"}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2 md:ml-2">
            <button type="button" className="min-h-11 rounded-full border border-line px-3 text-xs" onClick={cycleTheme} aria-label={`Theme ${theme}`}>
              {theme === "system" ? "System" : theme === "light" ? "Light" : "Dark"}
            </button>
            {isPending ? <span className="h-9 w-16 animate-pulse rounded-full bg-paper" /> : null}
            {!isPending && !user ? (
              <Link to="/login" className="inline-flex min-h-11 items-center rounded-full bg-fg px-4 text-sm text-bg">
                Sign in
              </Link>
            ) : null}
            {!isPending && user ? (
              <Link to="/learn" className="hidden min-h-11 items-center text-sm sm:inline-flex">
                Learn
              </Link>
            ) : null}
            {role === "admin" ? (
              <Link to="/admin" className="hidden min-h-11 items-center text-sm text-accent-ink sm:inline-flex">
                Admin
              </Link>
            ) : null}
            <button type="button" className="inline-flex min-h-11 min-w-11 items-center justify-center md:hidden" aria-expanded={open} aria-label="Menu" onClick={() => setOpen((value) => !value)}>
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {open ? (
          <nav className="grid border-t border-line px-4 py-2 md:hidden" aria-label="Mobile">
            {NAV.map((item) => (
              <Link key={item.to} to={item.to} className="flex min-h-11 items-center text-base">
                {item.label}
              </Link>
            ))}
            {user ? <Link to="/learn" className="flex min-h-11 items-center">Student dashboard</Link> : null}
            {role === "admin" ? <Link to="/admin" className="flex min-h-11 items-center">Admin</Link> : null}
          </nav>
        ) : null}
      </header>
      <div id="content">{children}</div>
      <footer className="mt-16 border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-2">
          <div>
            <p className="font-display text-2xl">QIVENEX AI ACADEMY</p>
            <p className="mt-2 max-w-sm text-sm text-muted">Founded by Chris Vincent. Practical AI education for beginners, builders, and entrepreneurs.</p>
            {chrome.showFooterSocial ? <SocialRow links={links} /> : null}
          </div>
          <div className="grid content-start gap-2 text-sm">
            <Link to="/courses" className="min-h-11">Courses</Link>
            <Link to="/community" className="min-h-11">Community</Link>
            <Link to="/contact" className="min-h-11">Contact</Link>
            <a href="/sitemap.xml" className="min-h-11">Sitemap</a>
            <div className="pt-2"><UserButton /></div>
          </div>
        </div>
        <p className="border-t border-line px-4 py-4 text-center text-xs text-muted">
          Payments open on Selar and are not confirmed until an administrator verifies them.
        </p>
      </footer>
    </div>
  );
}

export function SocialRow({ links }: { links: ReturnType<typeof socialLinks> }) {
  if (!links.length) return null;
  return (
    <div className="mt-4 flex flex-wrap gap-2">
      {links.map((link) => (
        <a key={link.id} href={link.href} target="_blank" rel="noopener noreferrer" aria-label={link.label} className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line">
          <SocialGlyph name={link.id} />
        </a>
      ))}
    </div>
  );
}

function SocialGlyph({ name }: { name: SocialKey }) {
  const common = { width: 18, height: 18, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, "aria-hidden": true as const };
  if (name === "youtube") return <svg {...common}><path d="M4 8.5a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3z" /><path d="m11 10 4 2-4 2z" /></svg>;
  if (name === "whatsapp") return <svg {...common}><path d="M6 18.5 7 15A7 7 0 1 1 9.2 18z" /><path d="M9 10.5c.4 1.6 2 3 3.6 3.4" /></svg>;
  if (name === "instagram") return <svg {...common}><rect x="5" y="5" width="14" height="14" rx="4" /><circle cx="12" cy="12" r="3" /><circle cx="16.5" cy="7.5" r="0.6" fill="currentColor" /></svg>;
  if (name === "facebook") return <svg {...common}><path d="M14 8h2V5h-2c-2 0-3 1.2-3 3v2H9v3h2v6h3v-6h2l1-3h-3V8c0-.6.3-1 1-1z" /></svg>;
  if (name === "tiktok") return <svg {...common}><path d="M14 6c.6 2.2 2 3.4 4 3.6v2.4c-1.4 0-2.7-.4-4-1.2v5.4a4.6 4.6 0 1 1-4-4.6" /></svg>;
  if (name === "x") return <svg {...common}><path d="M6 6 18 18M18 6 6 18" /></svg>;
  return <svg {...common}><rect x="5" y="5" width="14" height="14" rx="2" /><path d="M8 11v5M8 8h.01M12 16v-3a2 2 0 0 1 4 0v3" /></svg>;
}

export function Monogram() {
  return (
    <svg viewBox="0 0 48 48" className="h-10 w-10" aria-hidden="true">
      <rect width="48" height="48" rx="12" className="fill-ink" />
      <path d="M24 10c6.4 0 11 4.4 11 10.2S30.4 30.4 24 30.4 13 26 13 20.2 17.6 10 24 10zm0 5.2c-2.8 0-4.8 2-4.8 5s2 5 4.8 5 4.8-2 4.8-5-2-5-4.8-5z" className="fill-paper" />
      <path d="M28.2 28.2 35 36" className="stroke-paper" strokeWidth="2.2" fill="none" />
      <rect x="18" y="36" width="16" height="2.2" rx="1" className="fill-accent" />
    </svg>
  );
}

export function PageIntro({ eyebrow, title, body }: { eyebrow?: string; title: string; body?: string }) {
  return (
    <header className="mx-auto max-w-6xl px-4 pt-10">
      {eyebrow ? <p className="text-xs tracking-[0.18em] text-accent-ink uppercase">{eyebrow}</p> : null}
      <h1 className="mt-2 max-w-3xl text-4xl sm:text-5xl">{title}</h1>
      {body ? <p className="mt-4 max-w-2xl text-muted">{body}</p> : null}
    </header>
  );
}
