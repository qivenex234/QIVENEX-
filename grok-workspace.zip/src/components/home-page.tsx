import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { difficultyLabel, formatNaira, socialLinks } from "@/lib/academy";
import type { HomeData } from "@/server/public";
import { recordCheckoutIntent } from "@/server/student";
import { submitContact } from "@/server/public";
import { SocialRow } from "@/components/shell";
import { Button, Empty, Status, TextArea, TextInput } from "@/components/ui";

export function HomePage({ data }: { data: HomeData }) {
  const { chrome } = data;
  const org = {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: "QIVENEX AI ACADEMY",
    url: chrome.canonicalUrl,
    founder: { "@type": "Person", name: "Chris Vincent" },
    sameAs: socialLinks(chrome).map((link) => link.href),
  };
  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(org) }} />
      <section className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-16">
        <div className="rise">
          <p className="text-xs tracking-widest text-accent-ink uppercase">{chrome.heroKicker}</p>
          <h1 className="mt-3 text-4xl sm:text-6xl">{chrome.heroTitle}</h1>
          <p className="mt-5 max-w-xl text-lg text-muted">{chrome.heroBody}</p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <a href={chrome.sections.courses ? "#courses" : "/courses"} className="inline-flex min-h-11 items-center justify-center rounded-full bg-fg px-5 text-sm text-bg">
              Explore Our Courses
            </a>
            <a href={chrome.whatsappUrl} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-11 items-center justify-center rounded-full border border-line bg-surface px-5 text-sm">
              Join Our Community
            </a>
          </div>
        </div>
        <figure className="overflow-hidden rounded-card border border-line bg-ink">
          <img
            src={chrome.hasCustomHero ? "/brand/hero" : "/media/hero.jpg"}
            alt="A quiet study desk with a laptop, notebook, and lamp"
            className="aspect-video w-full object-cover"
          />
        </figure>
      </section>

      {chrome.sections.about ? (
        <section className="mx-auto grid max-w-6xl gap-8 px-4 py-8 lg:grid-cols-2" id="about">
          <img
            src={chrome.hasCustomAbout ? "/brand/about" : "/media/studio.jpg"}
            alt="An empty learning studio with a long table and warm daylight"
            className="aspect-video w-full rounded-card object-cover"
          />
          <div>
            <p className="text-xs tracking-widest text-accent-ink uppercase">About the academy</p>
            <h2 className="mt-2 text-3xl sm:text-4xl">{chrome.aboutTitle}</h2>
            <p className="mt-4 text-muted">{chrome.aboutBody}</p>
            <p className="mt-4 border-l-2 border-accent pl-4 text-sm">{chrome.founderNote}</p>
          </div>
        </section>
      ) : null}

      {chrome.sections.courses ? (
        <section id="courses" className="mx-auto max-w-6xl px-4 py-10">
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="text-xs tracking-widest text-accent-ink uppercase">Courses</p>
              <h2 className="mt-2 text-3xl sm:text-4xl">What you can learn</h2>
            </div>
            <Link to="/courses" className="hidden min-h-11 items-center text-sm sm:inline-flex">All courses</Link>
          </div>
          <p className="mt-3 max-w-2xl text-sm text-muted">Lesson materials appear inside a course only after the academy uploads them. A listing is not a claim that videos are already available.</p>
          {data.courses.length ? (
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {data.courses.map((course) => (
                <Link key={course.id} to="/courses/$slug" params={{ slug: course.slug }} className="overflow-hidden rounded-card border border-line bg-surface transition-colors hover:border-accent">
                  {course.cover ? <img src={course.cover} alt="" className="aspect-video w-full object-cover" /> : null}
                  <div className="p-4">
                    <p className="text-xs text-accent-ink">{course.category}</p>
                    <h3 className="mt-1 text-2xl">{course.title}</h3>
                    <p className="mt-2 text-sm text-muted">{course.description}</p>
                    <p className="mt-3 text-xs text-muted">{difficultyLabel(course.difficulty)}{course.lessonCount ? ` · ${course.lessonCount} lesson${course.lessonCount === 1 ? "" : "s"} uploaded` : " · No lessons uploaded yet"}</p>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="mt-6"><Empty title="Courses will appear here" body="Nothing is published yet. The administrator can add and publish courses from the dashboard." /></div>
          )}
        </section>
      ) : null}

      {chrome.sections.pricing ? (
        <section id="pricing" className="mx-auto max-w-6xl px-4 py-10">
          <p className="text-xs tracking-widest text-accent-ink uppercase">Pricing</p>
          <h2 className="mt-2 text-3xl sm:text-4xl">Three clear plans</h2>
          <p className="mt-3 max-w-2xl text-sm text-muted">Each button opens the matching Selar checkout in a new tab. This website does not take card details and does not mark a payment as complete when you click.</p>
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            {data.plans.map((plan) => (
              <article key={plan.code} className={`rounded-card border bg-surface p-5 ${plan.code === "standard" ? "border-accent" : "border-line"}`}>
                <p className="text-xs tracking-widest text-muted uppercase">{plan.name}</p>
                <p className="mt-3 font-display text-4xl tabular-nums">{formatNaira(plan.priceNgn)}</p>
                <p className="mt-3 text-sm text-muted">{plan.description}</p>
                <ul className="mt-4 grid gap-2 text-sm">
                  {plan.features.map((feature) => <li key={feature}>{feature}</li>)}
                </ul>
                <PayLink href={plan.checkoutUrl} planCode={plan.code} label={`Pay ${formatNaira(plan.priceNgn)} on Selar`} />
              </article>
            ))}
          </div>
        </section>
      ) : null}

      {chrome.sections.projects ? (
        <section id="projects" className="mx-auto max-w-6xl px-4 py-10">
          <p className="text-xs tracking-widest text-accent-ink uppercase">Student work</p>
          <h2 className="mt-2 text-3xl sm:text-4xl">Projects and achievements</h2>
          <p className="mt-3 max-w-2xl text-sm text-muted">Work is public only after an administrator approves it. Names are the display names students choose. The academy does not invent testimonials or results.</p>
          {data.projects.length ? (
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {data.projects.map((project) => (
                <article key={project.id} className="rounded-card border border-line bg-surface p-4">
                  {project.hasImage ? <img src={`/brand/project-${project.id}`} alt="" className="mb-3 aspect-video w-full rounded-xl object-cover" /> : null}
                  <h3 className="text-2xl">{project.title}</h3>
                  <p className="mt-1 text-sm text-muted">{project.studentName} · {project.createdOn}</p>
                  <p className="mt-3 text-sm">{project.description}</p>
                  {project.skills ? <p className="mt-2 text-xs text-accent-ink">{project.skills}</p> : null}
                </article>
              ))}
            </div>
          ) : (
            <div className="mt-6">
              <Empty title="No published student work yet" body="This space stays empty until a real submission is reviewed and approved. Sample stories are not shown as if they were real." />
            </div>
          )}
        </section>
      ) : null}

      {chrome.sections.community ? (
        <section id="community" className="mx-auto max-w-6xl px-4 py-10">
          <p className="text-xs tracking-widest text-accent-ink uppercase">Community</p>
          <h2 className="mt-2 text-3xl sm:text-4xl">Keep learning together</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <a href={chrome.youtubeUrl} target="_blank" rel="noopener noreferrer" className="rounded-card border border-line bg-surface p-5">
              <h3 className="text-2xl">Watch tutorials on YouTube</h3>
              <p className="mt-2 text-sm text-muted">The official QIVENEX AI ACADEMY channel.</p>
            </a>
            <a href={chrome.whatsappUrl} target="_blank" rel="noopener noreferrer" className="rounded-card border border-line bg-surface p-5">
              <h3 className="text-2xl">Join the WhatsApp Channel</h3>
              <p className="mt-2 text-sm text-muted">Announcements, classes, and bootcamps when they are published.</p>
            </a>
          </div>
          {chrome.showHeaderSocial ? <SocialRow links={socialLinks(chrome)} /> : null}
          <div className="mt-6 grid gap-3">
            {data.announcements.length ? data.announcements.map((item) => (
              <article key={item.id} className="rounded-card border border-line p-4">
                <p className="text-xs tracking-widest text-muted uppercase">{item.kind} · {item.createdOn}</p>
                <h3 className="mt-1 text-xl">{item.title}</h3>
                <p className="mt-2 text-sm text-muted">{item.body}</p>
              </article>
            )) : <Empty title="No announcements yet" body="Class dates, bootcamps, and notices will show here when the academy publishes them." />}
          </div>
          {data.videos.length ? (
            <ul className="mt-4 grid gap-2 text-sm">
              {data.videos.map((video) => (
                <li key={video.id}><a className="underline" href={video.url} target="_blank" rel="noopener noreferrer">{video.title}</a></li>
              ))}
            </ul>
          ) : null}
        </section>
      ) : null}

      {chrome.sections.faq ? (
        <section id="faq" className="mx-auto max-w-6xl px-4 py-10">
          <h2 className="text-3xl sm:text-4xl">Questions</h2>
          <div className="mt-5 grid gap-2">
            {data.faqs.map((faq) => <FaqItem key={faq.id} question={faq.question} answer={faq.answer} />)}
          </div>
        </section>
      ) : null}

      {chrome.sections.contact ? (
        <section id="contact" className="mx-auto max-w-6xl px-4 py-10">
          <h2 className="text-3xl sm:text-4xl">Contact</h2>
          <p className="mt-3 max-w-2xl text-sm text-muted">{chrome.contactNote}</p>
          {chrome.contactEmail ? <p className="mt-2 text-sm">Email: <a className="underline" href={`mailto:${chrome.contactEmail}`}>{chrome.contactEmail}</a></p> : <p className="mt-2 text-sm text-muted">No public email address has been added yet.</p>}
          <ContactForm />
        </section>
      ) : null}
    </main>
  );
}

function PayLink({ href, planCode, label }: { href: string; planCode: string; label: string }) {
  const user = useCurrentUser();
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-5 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-fg px-4 text-sm text-bg"
      onClick={() => {
        if (!user) return;
        void recordCheckoutIntent({ data: { planCode } }).catch(() => undefined);
      }}
    >
      {label}
    </a>
  );
}

function FaqItem({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border border-line bg-surface">
      <button type="button" className="flex min-h-11 w-full items-center justify-between gap-4 px-4 py-3 text-left" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        <span className="font-medium">{question}</span>
        <span aria-hidden="true">{open ? "–" : "+"}</span>
      </button>
      {open ? <p className="px-4 pb-4 text-sm text-muted">{answer}</p> : null}
    </div>
  );
}

function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [company, setCompany] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  return (
    <form
      className="mt-5 grid max-w-xl gap-3"
      onSubmit={(event) => {
        event.preventDefault();
        setPending(true);
        setError(null);
        setOk(null);
        void submitContact({ data: { name, email, message, company } })
          .then((result) => {
            if (!result.ok) setError(result.error);
            else {
              setOk("Your message has been received.");
              setName("");
              setEmail("");
              setMessage("");
            }
          })
          .catch(() => setError("The message could not be sent. Try again."))
          .finally(() => setPending(false));
      }}
    >
      <div className="absolute h-0 overflow-hidden">
        <label>Company<input value={company} onChange={(event) => setCompany(event.target.value)} tabIndex={-1} autoComplete="off" /></label>
      </div>
      <TextInput aria-label="Name" placeholder="Your name" value={name} onChange={(event) => setName(event.target.value)} required />
      <TextInput aria-label="Email" type="email" placeholder="Email address" value={email} onChange={(event) => setEmail(event.target.value)} required />
      <TextArea aria-label="Message" placeholder="How can the academy help?" value={message} onChange={(event) => setMessage(event.target.value)} required />
      <Button type="submit" disabled={pending}>{pending ? "Sending…" : "Send message"}</Button>
      <Status error={error} ok={ok} />
    </form>
  );
}
