import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { difficultyLabel, formatNaira, type PlanCode } from "@/lib/academy";
import {
  claimPayment,
  downloadCertificate,
  getLearning,
  getLessons,
  listStudentExams,
  submitExam,
  submitWork,
  updateProfile,
} from "@/server/student";
import { getCatalog } from "@/server/public";
import { Button, Empty, Field, Status, TextArea, TextInput, fileToImage, savePdf } from "@/components/ui";

type Tab = "home" | "courses" | "work" | "exams" | "profile";

export function LearnPage() {
  const { user, isPending } = useCurrentUserState();
  const [tab, setTab] = useState<Tab>("home");
  if (isPending) return <main className="mx-auto max-w-6xl px-4 py-16 text-sm text-muted">Opening your account…</main>;
  if (!user) return <RedirectToSignIn />;
  const tabs: Array<[Tab, string]> = [
    ["home", "Home"],
    ["courses", "Courses"],
    ["work", "Work"],
    ["exams", "Exams"],
    ["profile", "Profile"],
  ];
  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <p className="text-xs tracking-widest text-accent-ink uppercase">Student dashboard</p>
      <h1 className="mt-2 text-4xl">Welcome{user.displayName ? `, ${user.displayName}` : ""}</h1>
      <div className="mt-5 flex gap-2 overflow-x-auto pb-2">
        {tabs.map(([id, label]) => (
          <button key={id} type="button" className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${tab === id ? "bg-fg text-bg" : "border border-line"}`} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>
      {tab === "home" ? <HomeTab /> : null}
      {tab === "courses" ? <CoursesTab /> : null}
      {tab === "work" ? <WorkTab /> : null}
      {tab === "exams" ? <ExamsTab /> : null}
      {tab === "profile" ? <ProfileTab initialName={user.displayName ?? ""} /> : null}
    </main>
  );
}

function HomeTab() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getLearning>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    getLearning().then(setData).catch((err: Error) => setError(err.message));
  }, []);
  if (error) return <Status error={error} />;
  if (!data) return <p className="text-sm text-muted">Loading your records…</p>;
  if (data.member.status !== "active") return <Status error="This account is suspended. Contact the academy if you think that is a mistake." />;
  return (
    <div className="grid gap-4">
      <p className="max-w-2xl text-sm text-muted">Enrollment stays pending until an administrator verifies a payment. Opening Selar does not confirm payment.</p>
      {data.enrollments.length ? (
        <div className="grid gap-2">
          {data.enrollments.map((item) => (
            <article key={item.id} className="rounded-card border border-line p-4 text-sm">
              <p className="font-medium">{item.plan_code ? `${item.plan_code} plan` : item.course_title ?? "Course enrollment"}</p>
              <p className="text-muted">{labelStatus(item.status)} · {item.created_on}</p>
              <p className="mt-1 text-muted">{sourceCopy(item.source)}</p>
            </article>
          ))}
        </div>
      ) : <Empty title="No enrollment records yet" body="Choose a plan on the homepage. If you have already paid on Selar, use the Courses tab to tell the academy." />}
      <h2 className="text-2xl">Announcements</h2>
      {data.announcements.length ? data.announcements.map((item) => (
        <article key={item.id} className="rounded-card border border-line p-4">
          <p className="text-xs text-muted">{item.kind} · {item.created_on}</p>
          <h3 className="text-xl">{item.title}</h3>
          <p className="mt-2 text-sm text-muted">{item.body}</p>
        </article>
      )) : <Empty title="No announcements" body="When the academy publishes a notice, it will show here." />}
    </div>
  );
}

function CoursesTab() {
  const [plans, setPlans] = useState<Array<{ code: PlanCode; name: string; priceNgn: number; checkoutUrl: string }>>([]);
  const [courses, setCourses] = useState<Awaited<ReturnType<typeof getLearning>>["courses"]>([]);
  const [slug, setSlug] = useState<string | null>(null);
  const [lessons, setLessons] = useState<Array<{ id: number; title: string; body: string; material_url: string | null }>>([]);
  const [unlocked, setUnlocked] = useState(false);
  const [plan, setPlan] = useState<PlanCode>("starter");
  const [note, setNote] = useState("");
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    getCatalog().then((catalog) => setPlans(catalog.plans)).catch(() => undefined);
    getLearning().then((data) => setCourses(data.courses)).catch((err: Error) => setError(err.message));
  }, []);
  return (
    <div className="grid gap-5">
      <Status error={error} ok={status} />
      <form className="grid gap-3 rounded-card border border-line p-4" onSubmit={(event) => {
        event.preventDefault();
        claimPayment({ data: { planCode: plan, note } })
          .then((result) => {
            if (!result.ok) setError(result.error ?? "Could not save that.");
            else setStatus("Saved as waiting for verification. This is not a payment confirmation.");
          })
          .catch(() => setError("Could not save that."));
      }}>
        <h2 className="text-2xl">I have paid</h2>
        <p className="text-sm text-muted">Use this only after you complete payment on Selar. An administrator still has to verify it.</p>
        <Field label="Plan">
          <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={plan} onChange={(event) => setPlan(event.target.value as PlanCode)}>
            {plans.map((item) => <option key={item.code} value={item.code}>{item.name} · {formatNaira(item.priceNgn)}</option>)}
          </select>
        </Field>
        <Field label="Note for the academy" hint="A Selar reference is enough. Do not enter a card number.">
          <TextInput value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
        <Button type="submit">Submit for verification</Button>
      </form>
      <div className="grid gap-3">
        {courses.map((course) => (
          <article key={course.id} className="rounded-card border border-line p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-2xl">{course.title}</h3>
                <p className="text-sm text-muted">{difficultyLabel(course.difficulty)} · {course.unlocked ? "Enrollment verified" : "Locked until enrollment is verified"} · {course.lessonCount ? `${course.lessonCount} uploaded` : "No lessons uploaded yet"}</p>
              </div>
              {course.unlocked ? (
                <Button type="button" variant="line" onClick={() => {
                  setSlug(course.slug);
                  getLessons({ data: course.slug }).then((result) => {
                    setUnlocked(result.unlocked);
                    setLessons(result.lessons);
                  }).catch(() => setError("Could not open the lessons."));
                }}>Open lessons</Button>
              ) : (
                <Link to="/courses/$slug" params={{ slug: course.slug }} className="inline-flex min-h-11 items-center text-sm underline">View course</Link>
              )}
            </div>
            {slug === course.slug && unlocked ? (
              <div className="mt-4 grid gap-3">
                {lessons.length ? lessons.map((lesson) => (
                  <div key={lesson.id}>
                    <h4 className="font-medium">{lesson.title}</h4>
                    <p className="mt-1 whitespace-pre-wrap text-sm text-muted">{lesson.body || "No lesson text yet."}</p>
                    {lesson.material_url ? <a className="text-sm underline" href={lesson.material_url} target="_blank" rel="noopener noreferrer">Open material</a> : null}
                  </div>
                )) : <p className="text-sm text-muted">Your access is verified, and no lesson has been uploaded for this course yet.</p>}
              </div>
            ) : null}
          </article>
        ))}
      </div>
    </div>
  );
}

function WorkTab() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [skills, setSkills] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [media, setMedia] = useState("");
  const [items, setItems] = useState<Awaited<ReturnType<typeof getLearning>>["submissions"]>([]);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  function reload() {
    getLearning().then((data) => setItems(data.submissions)).catch(() => undefined);
  }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-4">
      <p className="text-sm text-muted">Submissions stay private. They are shown on the public site only if an administrator approves them for the showcase. Send work you are willing for the academy to review.</p>
      <form className="grid gap-3" onSubmit={(event) => {
        event.preventDefault();
        setError(null);
        submitWork({ data: { title, description, skills, media, videoUrl } })
          .then((result) => {
            if (!result.ok) setError(result.error ?? "Could not submit.");
            else {
              setOk("Submitted for review.");
              setTitle("");
              setDescription("");
              setSkills("");
              setVideoUrl("");
              setMedia("");
              reload();
            }
          })
          .catch(() => setError("Could not submit."));
      }}>
        <Field label="Title"><TextInput value={title} onChange={(event) => setTitle(event.target.value)} required /></Field>
        <Field label="What you made"><TextArea value={description} onChange={(event) => setDescription(event.target.value)} required /></Field>
        <Field label="Skills shown"><TextInput value={skills} onChange={(event) => setSkills(event.target.value)} /></Field>
        <Field label="Video link" hint="Optional https link."><TextInput value={videoUrl} onChange={(event) => setVideoUrl(event.target.value)} /></Field>
        <Field label="Image" hint="Optional. It stays private until a showcase is approved.">
          <input className="text-sm" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            fileToImage(file).then(setMedia).catch((err: Error) => setError(err.message));
          }} />
        </Field>
        <Button type="submit">Submit work</Button>
        <Status error={error} ok={ok} />
      </form>
      {items.length ? items.map((item) => (
        <article key={item.id} className="rounded-card border border-line p-4 text-sm">
          <h3 className="text-xl">{item.title}</h3>
          <p className="text-muted">{item.status} · {item.created_on}{item.showcase ? " · On the public showcase" : ""}</p>
          {item.admin_note ? <p className="mt-2">Note from the academy: {item.admin_note}</p> : null}
        </article>
      )) : <Empty title="No submissions yet" body="When you send project work, its review status will show here." />}
    </div>
  );
}

function ExamsTab() {
  const [data, setData] = useState<Awaited<ReturnType<typeof listStudentExams>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  function reload() {
    listStudentExams().then(setData).catch((err: Error) => setError(err.message));
  }
  useEffect(() => { reload(); }, []);
  if (!data) return error ? <Status error={error} /> : <p className="text-sm text-muted">Loading exams…</p>;
  return (
    <div className="grid gap-5">
      <Status error={error} ok={ok} />
      {data.certificates.length ? (
        <div className="grid gap-2">
          <h2 className="text-2xl">Certificates</h2>
          {data.certificates.map((item) => (
            <div key={item.public_id} className="flex flex-wrap items-center justify-between gap-3 rounded-card border border-line p-4">
              <div>
                <p className="font-medium">{item.title}</p>
                <p className="text-sm text-muted">{item.public_id} · {item.issued_on}</p>
              </div>
              <Button type="button" variant="line" onClick={() => {
                downloadCertificate({ data: item.public_id }).then((result) => {
                  if (!result.ok) setError(result.error ?? "Could not download.");
                  else savePdf(result.filename, result.base64);
                }).catch(() => setError("Could not download."));
              }}>Download PDF</Button>
            </div>
          ))}
        </div>
      ) : <Empty title="No certificate yet" body="A certificate appears here only after you pass a published exam and the academy issues it. Eligibility is not the same as a certificate." />}
      {data.exams.length ? data.exams.map((exam) => (
        <article key={exam.id} className="rounded-card border border-line p-4">
          <h2 className="text-2xl">{exam.title}</h2>
          <p className="mt-1 text-sm text-muted">Pass mark {exam.passMark}%{exam.deadline ? ` · Deadline ${exam.deadline} UTC` : ""}</p>
          {exam.instructions ? <p className="mt-2 text-sm">{exam.instructions}</p> : null}
          {exam.attempt ? <p className="mt-3 text-sm">Result: {exam.attempt.score}/{exam.attempt.max_score}. {exam.attempt.passed ? "You passed. A certificate is available only after it is issued." : "You did not reach the pass mark."}</p> : (
            <form className="mt-4 grid gap-4" onSubmit={(event) => {
              event.preventDefault();
              submitExam({ data: { examId: exam.id, answers: exam.questions.map((q) => ({ questionId: q.id, choice: answers[q.id] ?? -1 })) } })
                .then((result) => {
                  if (!result.ok) setError(result.error ?? "Could not submit.");
                  else {
                    setOk(result.passed ? `Submitted. You passed with ${result.score}/${result.max}.` : `Submitted. Score ${result.score}/${result.max}.`);
                    reload();
                  }
                })
                .catch(() => setError("Could not submit."));
            }}>
              {exam.questions.map((question, index) => (
                <fieldset key={question.id} className="grid gap-2">
                  <legend className="font-medium">{index + 1}. {question.prompt}</legend>
                  {question.options.map((option, choice) => (
                    <label key={option} className="flex min-h-11 items-center gap-2 text-sm">
                      <input type="radio" name={`q-${question.id}`} checked={answers[question.id] === choice} onChange={() => setAnswers((current) => ({ ...current, [question.id]: choice }))} />
                      {option}
                    </label>
                  ))}
                </fieldset>
              ))}
              <Button type="submit">Submit exam</Button>
            </form>
          )}
        </article>
      )) : <p className="text-sm text-muted">No exam has been published.</p>}
    </div>
  );
}

function ProfileTab({ initialName }: { initialName: string }) {
  const [displayName, setDisplayName] = useState(initialName);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  return (
    <form className="grid max-w-md gap-3" onSubmit={(event) => {
      event.preventDefault();
      updateProfile({ data: { displayName } })
        .then((result) => {
          if (!result.ok) setError(result.error ?? "Could not update.");
          else setOk("Name updated. This does not change your sign-in email.");
        })
        .catch(() => setError("Could not update."));
    }}>
      <Field label="Display name" hint="This is the name used on showcases and certificates. Your email stays with your account.">
        <TextInput value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
      </Field>
      <Button type="submit">Save profile</Button>
      <Status error={error} ok={ok} />
    </form>
  );
}

function labelStatus(status: string) {
  if (status === "verified") return "Enrollment verified by an administrator";
  if (status === "revoked") return "Access revoked";
  return "Waiting for verification";
}

function sourceCopy(source: string) {
  if (source === "checkout_click") return "You opened Selar. That click is not a payment.";
  if (source === "manual_claim") return "You told the academy you paid. Still waiting for verification.";
  return "Recorded by the academy.";
}
