import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatNaira, OFFICIAL, type Chrome, type PlanCode, type Sections } from "@/lib/academy";
import { getChrome } from "@/server/public";
import { claimAdmin, getMyAccess } from "@/server/student";
import {
  adminAnnouncements,
  adminAudit,
  adminCertificates,
  adminEnrollments,
  adminExams,
  adminFaqs,
  adminLessons,
  adminListCourses,
  adminMessages,
  adminPlans,
  adminStudents,
  adminSubmissions,
  adminVideos,
  createEnrollment,
  deleteAnnouncement,
  deleteCourse,
  deleteFaq,
  deleteLesson,
  deleteQuestion,
  deleteVideo,
  getOverview,
  issueCertificate,
  markMessage,
  moveCourse,
  resetAttempt,
  reviewSubmission,
  rotateAccessCode,
  saveAnnouncement,
  saveBrand,
  saveContent,
  saveCourse,
  saveExam,
  saveFaq,
  saveLesson,
  savePlan,
  saveQuestion,
  saveSeo,
  saveVideo,
  setEnrollmentStatus,
  setStudentStatus,
} from "@/server/admin";
import { Button, Empty, Field, Status, TextArea, TextInput, fileToImage } from "@/components/ui";

const SECTIONS = [
  ["overview", "Overview"],
  ["courses", "Courses"],
  ["students", "Students"],
  ["enrollments", "Payments"],
  ["work", "Student work"],
  ["news", "Announcements"],
  ["exams", "Exams"],
  ["certificates", "Certificates"],
  ["pages", "Homepage"],
  ["brand", "Brand"],
  ["seo", "SEO"],
  ["messages", "Messages"],
  ["audit", "Audit"],
  ["access", "Access"],
] as const;

type Section = (typeof SECTIONS)[number][0];

export function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  const [access, setAccess] = useState<Awaited<ReturnType<typeof getMyAccess>> | null>(null);
  const [ready, setReady] = useState(false);
  const [section, setSection] = useState<Section>("overview");
  useEffect(() => {
    if (!user) return;
    getMyAccess().then((value) => { setAccess(value); setReady(true); }).catch(() => setReady(true));
  }, [user]);
  if (isPending || (user && !ready)) return <main className="px-4 py-16 text-sm text-muted">Checking access…</main>;
  if (!user) return <RedirectToSignIn />;
  if (!access || access.role !== "admin") return <ClaimScreen configured={access?.adminConfigured ?? false} onGranted={() => getMyAccess().then(setAccess)} />;
  return (
    <main className="mx-auto grid max-w-6xl gap-4 px-4 py-6 lg:grid-cols-[200px_1fr]">
      <nav className="flex gap-2 overflow-x-auto lg:flex-col" aria-label="Admin">
        {SECTIONS.map(([id, label]) => (
          <button key={id} type="button" className={`min-h-11 shrink-0 rounded-full px-3 text-left text-sm lg:rounded-xl ${section === id ? "bg-fg text-bg" : "border border-line"}`} onClick={() => setSection(id)}>
            {label}
          </button>
        ))}
        <Link to="/" className="inline-flex min-h-11 items-center px-3 text-sm text-muted">View site</Link>
      </nav>
      <section className="min-w-0">
        {section === "overview" ? <Overview /> : null}
        {section === "courses" ? <Courses /> : null}
        {section === "students" ? <Students /> : null}
        {section === "enrollments" ? <Enrollments /> : null}
        {section === "work" ? <Work /> : null}
        {section === "news" ? <News /> : null}
        {section === "exams" ? <Exams /> : null}
        {section === "certificates" ? <Certificates /> : null}
        {section === "pages" ? <Pages /> : null}
        {section === "brand" ? <Brand /> : null}
        {section === "seo" ? <Seo /> : null}
        {section === "messages" ? <Messages /> : null}
        {section === "audit" ? <Audit /> : null}
        {section === "access" ? <Access /> : null}
      </section>
    </main>
  );
}

function ClaimScreen({ configured, onGranted }: { configured: boolean; onGranted: () => void }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  return (
    <main className="mx-auto max-w-md px-4 py-16">
      <h1 className="text-4xl">Administrator access</h1>
      <p className="mt-3 text-sm text-muted">Sign in with your own account, then enter the access code. It is checked only on the server. A student account never becomes an administrator by registering.</p>
      {!configured ? <p className="mt-3 text-sm text-danger">The server credential is not configured. Set QIVENEX_ADMIN_ACCESS_CODE in the hosting environment, then try again.</p> : null}
      <form className="mt-5 grid gap-3" onSubmit={(event) => {
        event.preventDefault();
        setPending(true);
        setError(null);
        claimAdmin({ data: code })
          .then((result) => {
            if (!result.ok && result.reason === "rate_limited") setError("Too many attempts. Wait fifteen minutes.");
            else if (!result.ok && result.reason === "unconfigured") setError("The server credential is not configured.");
            else if (!result.ok) setError("That code was not accepted.");
            else onGranted();
          })
          .catch(() => setError("Could not check the code."))
          .finally(() => setPending(false));
      }}>
        <Field label="Access code">
          <TextInput type="password" autoComplete="current-password" value={code} onChange={(event) => setCode(event.target.value)} />
        </Field>
        <Button type="submit" disabled={pending}>{pending ? "Checking…" : "Continue"}</Button>
        <Status error={error} />
      </form>
    </main>
  );
}

function Overview() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getOverview>> | null>(null);
  useEffect(() => { getOverview().then(setData).catch(() => undefined); }, []);
  if (!data?.counts) return <p className="text-sm text-muted">Loading records…</p>;
  const items = [
    ["Students", data.counts.students],
    ["Verified enrollments", data.counts.verified_enrollments],
    ["Waiting for verification", data.counts.pending_enrollments],
    ["Published courses", data.counts.published_courses],
    ["Submissions", data.counts.submissions],
    ["Pending submissions", data.counts.pending_submissions],
    ["Exam results", data.counts.exam_results],
    ["Certificates", data.counts.certificates],
    ["Unread messages", data.counts.unread_messages],
  ];
  return (
    <div>
      <h1 className="text-3xl">Overview</h1>
      <p className="mt-2 text-sm text-muted">These numbers come from the database. Empty means empty.</p>
      <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-3">
        {items.map(([label, value]) => (
          <article key={String(label)} className="rounded-card border border-line p-4">
            <p className="text-xs text-muted">{label}</p>
            <p className="mt-1 font-display text-3xl tabular-nums">{value}</p>
          </article>
        ))}
      </div>
      <h2 className="mt-6 text-2xl">Recent admin actions</h2>
      {data.recent.length ? <Log rows={data.recent} /> : <p className="mt-2 text-sm text-muted">No actions recorded yet.</p>}
    </div>
  );
}

function Courses() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminListCourses>>>([]);
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [error, setError] = useState<string | null>(null);
  function reload() { adminListCourses().then(setRows).catch((err: Error) => setError(err.message)); }
  useEffect(() => { reload(); }, []);
  const current = rows.find((row) => row.id === editing);
  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-3xl">Courses</h1>
        <Button type="button" onClick={() => setEditing("new")}>New course</Button>
      </div>
      <Status error={error} />
      {rows.map((course) => (
        <article key={course.id} className="rounded-card border border-line p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-xl">{course.title}</h2>
              <p className="text-xs text-muted">{course.published ? "Published" : "Unpublished"} · {course.lessonCount} lessons · {course.planCode ?? "No plan"}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="line" onClick={() => moveCourse({ data: { id: course.id, direction: "up" } }).then(reload)}>Up</Button>
              <Button type="button" variant="line" onClick={() => moveCourse({ data: { id: course.id, direction: "down" } }).then(reload)}>Down</Button>
              <Button type="button" variant="line" onClick={() => setEditing(course.id)}>Edit</Button>
              <Button type="button" variant="danger" onClick={() => { if (confirm("Delete this course?")) deleteCourse({ data: course.id }).then(reload); }}>Delete</Button>
            </div>
          </div>
          {editing === course.id ? <LessonEditor courseId={course.id} /> : null}
        </article>
      ))}
      {editing ? (
        <CourseForm
          initial={current}
          onDone={() => { setEditing(null); reload(); }}
        />
      ) : null}
    </div>
  );
}

function CourseForm({ initial, onDone }: { initial?: Awaited<ReturnType<typeof adminListCourses>>[number]; onDone: () => void }) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [category, setCategory] = useState(initial?.category ?? "");
  const [difficulty, setDifficulty] = useState(initial?.difficulty ?? "beginner");
  const [planCode, setPlanCode] = useState(initial?.planCode ?? "");
  const [checkoutUrl, setCheckoutUrl] = useState(initial?.checkoutUrl ?? "");
  const [outcomes, setOutcomes] = useState((initial?.outcomes ?? []).join("\n"));
  const [curriculum, setCurriculum] = useState(initial?.curriculum ?? "");
  const [published, setPublished] = useState(initial?.published ?? false);
  const [cover, setCover] = useState("");
  const [error, setError] = useState<string | null>(null);
  return (
    <form className="grid gap-3 rounded-card border border-line p-4" onSubmit={(event) => {
      event.preventDefault();
      saveCourse({ data: { id: initial?.id, title, description, category, difficulty, planCode, checkoutUrl, outcomes, curriculum, published, cover } })
        .then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else onDone(); })
        .catch(() => setError("Could not save."));
    }}>
      <h2 className="text-2xl">{initial ? "Edit course" : "New course"}</h2>
      <Field label="Title"><TextInput value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
      <Field label="Category"><TextInput value={category} onChange={(e) => setCategory(e.target.value)} /></Field>
      <Field label="Description"><TextArea value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
      <Field label="Difficulty">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={difficulty} onChange={(e) => setDifficulty(e.target.value as typeof difficulty)}>
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </Field>
      <Field label="Included with plan">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={planCode ?? ""} onChange={(e) => setPlanCode(e.target.value as PlanCode | "")}>
          <option value="">Not tied to a plan</option>
          <option value="starter">Starter</option>
          <option value="basic">Basic</option>
          <option value="standard">Standard</option>
        </select>
      </Field>
      <Field label="Optional direct checkout" hint="Leave empty to use the plan buttons. https only."><TextInput value={checkoutUrl ?? ""} onChange={(e) => setCheckoutUrl(e.target.value)} /></Field>
      <Field label="Learning outcomes" hint="One per line. Do not promise lessons you have not uploaded."><TextArea value={outcomes} onChange={(e) => setOutcomes(e.target.value)} /></Field>
      <Field label="Curriculum outline" hint="Optional. Students still only see lesson text after enrollment."><TextArea value={curriculum ?? ""} onChange={(e) => setCurriculum(e.target.value)} /></Field>
      <Field label="Replace cover">
        <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) fileToImage(file).then(setCover).catch((err: Error) => setError(err.message));
        }} />
      </Field>
      <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} /> Published</label>
      <Button type="submit">Save course</Button>
      <Status error={error} />
    </form>
  );
}

function LessonEditor({ courseId }: { courseId: number }) {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminLessons>>>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [materialUrl, setMaterialUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  function reload() { adminLessons({ data: courseId }).then(setRows).catch(() => undefined); }
  useEffect(() => { reload(); }, [courseId]);
  return (
    <div className="mt-4 grid gap-2 border-t border-line pt-3">
      <h3 className="text-lg">Lessons</h3>
      {rows.map((lesson) => (
        <div key={lesson.id} className="flex items-center justify-between gap-2 text-sm">
          <span>{lesson.title}</span>
          <Button type="button" variant="danger" onClick={() => deleteLesson({ data: lesson.id }).then(reload)}>Remove</Button>
        </div>
      ))}
      <Field label="New lesson title"><TextInput value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
      <Field label="Lesson text"><TextArea value={body} onChange={(e) => setBody(e.target.value)} /></Field>
      <Field label="Material link"><TextInput value={materialUrl} onChange={(e) => setMaterialUrl(e.target.value)} /></Field>
      <Button type="button" variant="line" onClick={() => saveLesson({ data: { courseId, title, body, materialUrl } }).then((result) => {
        if (!result.ok) setError(result.error ?? "Could not save.");
        else { setTitle(""); setBody(""); setMaterialUrl(""); reload(); }
      })}>Add lesson</Button>
      <Status error={error} />
    </div>
  );
}

function Students() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminStudents>>>([]);
  const [query, setQuery] = useState("");
  function reload() { adminStudents().then(setRows).catch(() => undefined); }
  useEffect(() => { reload(); }, []);
  const shown = rows.filter((row) => `${row.display_name} ${row.email}`.toLowerCase().includes(query.toLowerCase()));
  return (
    <div>
      <h1 className="text-3xl">Students</h1>
      <p className="mt-2 text-sm text-muted">Registration never grants administrator access. You can suspend a student account. You cannot promote someone from this list.</p>
      <TextInput className="mt-3" placeholder="Find a name or email" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Find a student" />
      <div className="mt-4 grid gap-2">
        {shown.map((row) => (
          <article key={row.user_id} className="rounded-card border border-line p-3 text-sm">
            <p className="font-medium">{row.display_name}</p>
            <p className="text-muted">{row.email} · {row.role} · {row.status} · {row.created_on}</p>
            {row.role === "student" ? (
              <Button className="mt-2" type="button" variant="line" onClick={() => setStudentStatus({ data: { userId: row.user_id, status: row.status === "active" ? "suspended" : "active" } }).then(reload)}>
                {row.status === "active" ? "Suspend" : "Restore"}
              </Button>
            ) : null}
          </article>
        ))}
        {!shown.length ? <Empty title="No matching accounts" body="Students appear here after they create an account." /> : null}
      </div>
    </div>
  );
}

function Enrollments() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminEnrollments>>>([]);
  const [students, setStudents] = useState<Awaited<ReturnType<typeof adminStudents>>>([]);
  const [userId, setUserId] = useState("");
  const [planCode, setPlanCode] = useState<PlanCode>("starter");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  function reload() {
    adminEnrollments().then(setRows).catch(() => undefined);
    adminStudents().then(setStudents).catch(() => undefined);
  }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-4">
      <h1 className="text-3xl">Payments and enrollment</h1>
      <p className="text-sm text-muted">Selar does not notify this website automatically. Verify a payment only when you have actually checked it. Do not store card numbers.</p>
      <form className="grid gap-3 rounded-card border border-line p-4" onSubmit={(event) => {
        event.preventDefault();
        createEnrollment({ data: { userId, planCode, courseId: null, note, verified: true } })
          .then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else { setNote(""); reload(); } })
          .catch((err: Error) => setError(err.message));
      }}>
        <Field label="Student">
          <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={userId} onChange={(e) => setUserId(e.target.value)} required>
            <option value="">Choose</option>
            {students.filter((s) => s.role === "student").map((s) => <option key={s.user_id} value={s.user_id}>{s.display_name} · {s.email}</option>)}
          </select>
        </Field>
        <Field label="Plan">
          <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={planCode} onChange={(e) => setPlanCode(e.target.value as PlanCode)}>
            <option value="starter">Starter</option>
            <option value="basic">Basic</option>
            <option value="standard">Standard</option>
          </select>
        </Field>
        <Field label="Private note"><TextInput value={note} onChange={(e) => setNote(e.target.value)} /></Field>
        <Button type="submit">Record verified manual payment</Button>
        <Status error={error} />
      </form>
      {rows.map((row) => (
        <article key={row.id} className="rounded-card border border-line p-3 text-sm">
          <p className="font-medium">{row.display_name} · {row.email}</p>
          <p>{row.plan_code ?? row.course_title ?? "Enrollment"} · {row.status} · {row.source} · {row.created_on}</p>
          {row.note ? <p className="text-muted">{row.note}</p> : null}
          <div className="mt-2 flex flex-wrap gap-2">
            <Button type="button" variant="line" onClick={() => setEnrollmentStatus({ data: { id: row.id, status: "verified", note: row.note ?? "" } }).then(reload)}>Mark verified</Button>
            <Button type="button" variant="line" onClick={() => setEnrollmentStatus({ data: { id: row.id, status: "pending", note: row.note ?? "" } }).then(reload)}>Mark waiting</Button>
            <Button type="button" variant="danger" onClick={() => setEnrollmentStatus({ data: { id: row.id, status: "revoked", note: row.note ?? "" } }).then(reload)}>Revoke</Button>
          </div>
        </article>
      ))}
      {!rows.length ? <Empty title="No enrollment records" body="Checkout clicks from signed-in students, payment claims, and manual records will show here." /> : null}
    </div>
  );
}

function Work() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminSubmissions>>>([]);
  function reload() { adminSubmissions().then(setRows).catch(() => undefined); }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-3">
      <h1 className="text-3xl">Student work</h1>
      <p className="text-sm text-muted">Approving a showcase publishes the student’s display name, description, and image. Do that only with their consent.</p>
      {rows.map((row) => <SubmissionCard key={row.id} row={row} onChange={reload} />)}
      {!rows.length ? <Empty title="No submissions" body="Student project uploads will wait here for review." /> : null}
    </div>
  );
}

function SubmissionCard({ row, onChange }: { row: Awaited<ReturnType<typeof adminSubmissions>>[number]; onChange: () => void }) {
  const [note, setNote] = useState(row.admin_note ?? "");
  return (
    <article className="rounded-card border border-line p-4 text-sm">
      <h2 className="text-xl">{row.title}</h2>
      <p className="text-muted">{row.display_name} · {row.status} · {row.created_on}</p>
      <p className="mt-2">{row.description}</p>
      {row.skills ? <p className="mt-1 text-accent-ink">{row.skills}</p> : null}
      {row.video_url ? <a className="underline" href={row.video_url} target="_blank" rel="noopener noreferrer">Video</a> : null}
      {row.has_image ? <p className="text-muted">An image is attached and stays private unless you feature the work.</p> : null}
      <TextInput className="mt-2" value={note} onChange={(e) => setNote(e.target.value)} aria-label="Review note" />
      <div className="mt-2 flex flex-wrap gap-2">
        <Button type="button" variant="line" onClick={() => reviewSubmission({ data: { id: row.id, status: "approved", showcase: false, note } }).then(onChange)}>Approve privately</Button>
        <Button type="button" onClick={() => reviewSubmission({ data: { id: row.id, status: "approved", showcase: true, note } }).then(onChange)}>Approve and feature</Button>
        <Button type="button" variant="danger" onClick={() => reviewSubmission({ data: { id: row.id, status: "rejected", showcase: false, note } }).then(onChange)}>Reject</Button>
      </div>
    </article>
  );
}

function News() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminAnnouncements>>>([]);
  const [videos, setVideos] = useState<Awaited<ReturnType<typeof adminVideos>>>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [kind, setKind] = useState("news");
  const [published, setPublished] = useState(true);
  const [videoTitle, setVideoTitle] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  function reload() {
    adminAnnouncements().then(setRows).catch(() => undefined);
    adminVideos().then(setVideos).catch(() => undefined);
  }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-4">
      <h1 className="text-3xl">Announcements</h1>
      <form className="grid gap-3" onSubmit={(e) => {
        e.preventDefault();
        saveAnnouncement({ data: { title, body, kind, published } }).then((result) => {
          if (!result.ok) setError(result.error ?? "Could not save.");
          else { setTitle(""); setBody(""); reload(); }
        });
      }}>
        <Field label="Title"><TextInput value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        <Field label="Message"><TextArea value={body} onChange={(e) => setBody(e.target.value)} /></Field>
        <Field label="Kind">
          <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="news">News</option>
            <option value="class">Class</option>
            <option value="bootcamp">Bootcamp</option>
            <option value="notice">Notice</option>
          </select>
        </Field>
        <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} /> Published</label>
        <Button type="submit">Publish announcement</Button>
      </form>
      {rows.map((row) => (
        <article key={row.id} className="rounded-card border border-line p-3 text-sm">
          <p className="font-medium">{row.title}</p>
          <p className="text-muted">{row.kind} · {row.published ? "Published" : "Draft"} · {row.created_on}</p>
          <Button className="mt-2" type="button" variant="danger" onClick={() => deleteAnnouncement({ data: row.id }).then(reload)}>Delete</Button>
        </article>
      ))}
      <h2 className="text-2xl">Featured videos</h2>
      <form className="grid gap-3" onSubmit={(e) => {
        e.preventDefault();
        saveVideo({ data: { title: videoTitle, url: videoUrl, published: true } }).then((result) => {
          if (!result.ok) setError(result.error ?? "Could not save.");
          else { setVideoTitle(""); setVideoUrl(""); reload(); }
        });
      }}>
        <Field label="Video title"><TextInput value={videoTitle} onChange={(e) => setVideoTitle(e.target.value)} /></Field>
        <Field label="https link"><TextInput value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} /></Field>
        <Button type="submit" variant="line">Add video</Button>
        <Status error={error} />
      </form>
      {videos.map((video) => (
        <div key={video.id} className="flex items-center justify-between gap-2 text-sm">
          <span>{video.title}</span>
          <Button type="button" variant="danger" onClick={() => deleteVideo({ data: video.id }).then(reload)}>Remove</Button>
        </div>
      ))}
    </div>
  );
}

function Exams() {
  const [data, setData] = useState<Awaited<ReturnType<typeof adminExams>> | null>(null);
  const [title, setTitle] = useState("");
  const [instructions, setInstructions] = useState("");
  const [passMark, setPassMark] = useState(70);
  const [deadline, setDeadline] = useState("");
  const [examId, setExamId] = useState<number | null>(null);
  const [prompt, setPrompt] = useState("");
  const [options, setOptions] = useState("");
  const [correctIndex, setCorrectIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  function reload() { adminExams().then(setData).catch((err: Error) => setError(err.message)); }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-4">
      <h1 className="text-3xl">Exams</h1>
      <form className="grid gap-3" onSubmit={(e) => {
        e.preventDefault();
        saveExam({ data: { title, instructions, courseId: null, passMark, deadline, published: false } })
          .then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else { setExamId(result.id); setTitle(""); reload(); } });
      }}>
        <Field label="Exam title"><TextInput value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        <Field label="Instructions"><TextArea value={instructions} onChange={(e) => setInstructions(e.target.value)} /></Field>
        <Field label="Pass mark percent"><TextInput type="number" value={passMark} onChange={(e) => setPassMark(Number(e.target.value))} /></Field>
        <Field label="Deadline UTC" hint="Optional."><TextInput type="datetime-local" value={deadline} onChange={(e) => setDeadline(e.target.value)} /></Field>
        <Button type="submit">Create exam draft</Button>
      </form>
      <Field label="Add a question to">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={examId ?? ""} onChange={(e) => setExamId(Number(e.target.value))}>
          <option value="">Choose an exam</option>
          {data?.exams.map((exam) => <option key={exam.id} value={exam.id}>{exam.title}</option>)}
        </select>
      </Field>
      <Field label="Question"><TextInput value={prompt} onChange={(e) => setPrompt(e.target.value)} /></Field>
      <Field label="Options" hint="One per line. The correct option number starts at 1."><TextArea value={options} onChange={(e) => setOptions(e.target.value)} /></Field>
      <Field label="Correct option number"><TextInput type="number" value={correctIndex + 1} onChange={(e) => setCorrectIndex(Number(e.target.value) - 1)} /></Field>
      <Button type="button" variant="line" onClick={() => {
        if (!examId) return;
        saveQuestion({ data: { examId, prompt, options, correctIndex, points: 1 } }).then((result) => {
          if (!result.ok) setError(result.error ?? "Could not save.");
          else { setPrompt(""); setOptions(""); reload(); }
        });
      }}>Save question</Button>
      <Status error={error} />
      {data?.exams.map((exam) => (
        <article key={exam.id} className="rounded-card border border-line p-3 text-sm">
          <p className="font-medium">{exam.title} · {exam.published ? "Published" : "Draft"} · pass {exam.pass_mark}%</p>
          {(data.questions.filter((q) => q.exam_id === exam.id)).map((q) => (
            <div key={q.id} className="mt-2 flex justify-between gap-2">
              <span>{q.prompt}</span>
              <Button type="button" variant="danger" onClick={() => deleteQuestion({ data: q.id }).then(reload)}>Remove</Button>
            </div>
          ))}
          {!exam.published ? <Button className="mt-2" type="button" onClick={() => saveExam({ data: { id: exam.id, title: exam.title, instructions: exam.instructions, courseId: exam.course_id, passMark: exam.pass_mark, deadline: exam.deadline ?? "", published: true } }).then((r) => { if (!r.ok) setError(r.error ?? "Could not publish."); reload(); })}>Publish</Button> : null}
          {data.attempts.filter((a) => a.exam_id === exam.id).map((attempt) => (
            <div key={attempt.user_id} className="mt-2 flex flex-wrap items-center justify-between gap-2">
              <span>{attempt.display_name}: {attempt.score}/{attempt.max_score} · {attempt.passed ? "passed" : "not passed"}</span>
              <Button type="button" variant="line" onClick={() => resetAttempt({ data: { examId: exam.id, userId: attempt.user_id } }).then(reload)}>Reset attempt</Button>
            </div>
          ))}
        </article>
      ))}
    </div>
  );
}

function Certificates() {
  const [data, setData] = useState<Awaited<ReturnType<typeof adminCertificates>> | null>(null);
  const [pick, setPick] = useState("");
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  function reload() { adminCertificates().then(setData).catch(() => undefined); }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-3">
      <h1 className="text-3xl">Certificates</h1>
      <p className="text-sm text-muted">Issue a certificate only for a passing result. The public page shows the name, title, date, and identifier. It does not show an email address or a score.</p>
      <Field label="Eligible result">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={pick} onChange={(e) => {
          setPick(e.target.value);
          const item = data?.eligible.find((row) => `${row.user_id}:${row.exam_id}` === e.target.value);
          if (item) { setName(item.display_name); setTitle(item.exam_title); }
        }}>
          <option value="">Choose a passing student</option>
          {data?.eligible.map((row) => <option key={`${row.user_id}:${row.exam_id}`} value={`${row.user_id}:${row.exam_id}`}>{row.display_name} · {row.exam_title} · {row.score}/{row.max_score}</option>)}
        </select>
      </Field>
      <Field label="Name on certificate"><TextInput value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Title on certificate"><TextInput value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
      <Button type="button" onClick={() => {
        const [userId, examId] = pick.split(":");
        issueCertificate({ data: { userId, examId: Number(examId), studentName: name, title } }).then((result) => {
          if (!result.ok) setError(result.error ?? "Could not issue.");
          else { setOk(`Issued ${result.publicId}`); reload(); }
        });
      }}>Issue certificate</Button>
      <Status error={error} ok={ok} />
      {data?.issued.map((row) => (
        <p key={row.public_id} className="text-sm">{row.student_name} · {row.title} · {row.public_id} · {row.issued_on}</p>
      ))}
      {!data?.issued.length ? <Empty title="No certificates issued" body="Passing students will be listed above when an exam result qualifies them." /> : null}
    </div>
  );
}

function Pages() {
  const [chrome, setChrome] = useState<Chrome | null>(null);
  const [faqs, setFaqs] = useState<Awaited<ReturnType<typeof adminFaqs>>>([]);
  const [plans, setPlans] = useState<Awaited<ReturnType<typeof adminPlans>>>([]);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  useEffect(() => {
    getChrome().then(setChrome).catch(() => undefined);
    adminFaqs().then(setFaqs).catch(() => undefined);
    adminPlans().then(setPlans).catch(() => undefined);
  }, []);
  if (!chrome) return <p className="text-sm text-muted">Loading editor…</p>;
  return (
    <div className="grid gap-6">
      <h1 className="text-3xl">Homepage</h1>
      <form className="grid gap-3" onSubmit={(e) => {
        e.preventDefault();
        saveContent({ data: {
          heroKicker: chrome.heroKicker, heroTitle: chrome.heroTitle, heroBody: chrome.heroBody,
          aboutTitle: chrome.aboutTitle, aboutBody: chrome.aboutBody, founderNote: chrome.founderNote,
          contactEmail: chrome.contactEmail ?? "", contactNote: chrome.contactNote,
          sections: chrome.sections, autoIssueCertificates: chrome.autoIssueCertificates,
        } }).then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else setOk("Homepage saved."); });
      }}>
        <Editor chrome={chrome} setChrome={setChrome} />
        <Button type="submit">Save text and sections</Button>
      </form>
      <h2 className="text-2xl">Plans</h2>
      {plans.map((plan) => <PlanEditor key={plan.code} plan={plan} onSaved={() => adminPlans().then(setPlans)} />)}
      <h2 className="text-2xl">FAQs</h2>
      <FaqEditor onSaved={() => adminFaqs().then(setFaqs)} />
      {faqs.map((faq) => (
        <article key={faq.id} className="text-sm">
          <p className="font-medium">{faq.question}</p>
          <Button className="mt-1" type="button" variant="danger" onClick={() => deleteFaq({ data: faq.id }).then(() => adminFaqs().then(setFaqs))}>Delete</Button>
        </article>
      ))}
      <Status error={error} ok={ok} />
    </div>
  );
}

function Editor({ chrome, setChrome }: { chrome: Chrome; setChrome: (value: Chrome) => void }) {
  function set<K extends keyof Chrome>(key: K, value: Chrome[K]) { setChrome({ ...chrome, [key]: value }); }
  const sections: Array<[keyof Sections, string]> = [
    ["about", "About"], ["courses", "Courses"], ["pricing", "Pricing"], ["projects", "Projects"], ["community", "Community"], ["faq", "FAQ"], ["contact", "Contact"],
  ];
  return (
    <>
      <Field label="Welcome line"><TextInput value={chrome.heroKicker} onChange={(e) => set("heroKicker", e.target.value)} /></Field>
      <Field label="Headline"><TextInput value={chrome.heroTitle} onChange={(e) => set("heroTitle", e.target.value)} /></Field>
      <Field label="Supporting text"><TextArea value={chrome.heroBody} onChange={(e) => set("heroBody", e.target.value)} /></Field>
      <Field label="About title"><TextInput value={chrome.aboutTitle} onChange={(e) => set("aboutTitle", e.target.value)} /></Field>
      <Field label="About text"><TextArea value={chrome.aboutBody} onChange={(e) => set("aboutBody", e.target.value)} /></Field>
      <Field label="Founder note"><TextArea value={chrome.founderNote} onChange={(e) => set("founderNote", e.target.value)} /></Field>
      <Field label="Public contact email" hint="Leave empty if you do not want one published."><TextInput value={chrome.contactEmail ?? ""} onChange={(e) => set("contactEmail", e.target.value || null)} /></Field>
      <Field label="Contact note"><TextArea value={chrome.contactNote} onChange={(e) => set("contactNote", e.target.value)} /></Field>
      <label className="flex min-h-11 items-center gap-2 text-sm">
        <input type="checkbox" checked={chrome.autoIssueCertificates} onChange={(e) => set("autoIssueCertificates", e.target.checked)} />
        Issue a certificate automatically when a student passes
      </label>
      <div className="grid gap-2">
        {sections.map(([key, label]) => (
          <label key={key} className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={chrome.sections[key]} onChange={(e) => set("sections", { ...chrome.sections, [key]: e.target.checked })} />
            Show {label}
          </label>
        ))}
      </div>
    </>
  );
}

function PlanEditor({ plan, onSaved }: { plan: Awaited<ReturnType<typeof adminPlans>>[number]; onSaved: () => void }) {
  const [name, setName] = useState(plan.name);
  const [price, setPrice] = useState(plan.priceNgn);
  const [description, setDescription] = useState(plan.description);
  const [features, setFeatures] = useState(plan.features.join("\n"));
  const [checkoutUrl, setCheckoutUrl] = useState(plan.checkoutUrl);
  const [error, setError] = useState<string | null>(null);
  return (
    <form className="grid gap-2 rounded-card border border-line p-3" onSubmit={(e) => {
      e.preventDefault();
      savePlan({ data: { code: plan.code, name, priceNgn: price, description, features, checkoutUrl, published: true } })
        .then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else onSaved(); });
    }}>
      <p className="text-sm font-medium">{plan.code} · {formatNaira(plan.priceNgn)}</p>
      <TextInput aria-label="Plan name" value={name} onChange={(e) => setName(e.target.value)} />
      <TextInput aria-label="Price in naira" type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} />
      <TextArea aria-label="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
      <TextArea aria-label="Features" value={features} onChange={(e) => setFeatures(e.target.value)} />
      <TextInput aria-label="Checkout URL" value={checkoutUrl} onChange={(e) => setCheckoutUrl(e.target.value)} />
      <Button type="submit" variant="line">Save {plan.name}</Button>
      <Status error={error} />
    </form>
  );
}

function FaqEditor({ onSaved }: { onSaved: () => void }) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState<string | null>(null);
  return (
    <form className="grid gap-2" onSubmit={(e) => {
      e.preventDefault();
      saveFaq({ data: { question, answer, published: true } }).then((result) => {
        if (!result.ok) setError(result.error ?? "Could not save.");
        else { setQuestion(""); setAnswer(""); onSaved(); }
      });
    }}>
      <TextInput aria-label="Question" placeholder="Question" value={question} onChange={(e) => setQuestion(e.target.value)} />
      <TextArea aria-label="Answer" placeholder="Answer" value={answer} onChange={(e) => setAnswer(e.target.value)} />
      <Button type="submit" variant="line">Add FAQ</Button>
      <Status error={error} />
    </form>
  );
}

function Brand() {
  const [chrome, setChrome] = useState<Chrome | null>(null);
  const [files, setFiles] = useState({ logo: "", hero: "", about: "", icon: "" });
  const [clear, setClear] = useState({ logo: false, hero: false, about: false, icon: false });
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  useEffect(() => { getChrome().then(setChrome).catch(() => undefined); }, []);
  if (!chrome) return <p className="text-sm text-muted">Loading brand settings…</p>;
  async function onFile(key: "logo" | "hero" | "about" | "icon", file?: File) {
    if (!file) return;
    const image = await fileToImage(file);
    setFiles((current) => ({ ...current, [key]: image }));
  }
  return (
    <form className="grid gap-3" onSubmit={(e) => {
      e.preventDefault();
      saveBrand({ data: {
        themeMode: chrome.themeMode, accent: chrome.accent,
        youtubeUrl: chrome.youtubeUrl, whatsappUrl: chrome.whatsappUrl,
        facebookUrl: chrome.facebookUrl ?? "", instagramUrl: chrome.instagramUrl ?? "",
        tiktokUrl: chrome.tiktokUrl ?? "", xUrl: chrome.xUrl ?? "", linkedinUrl: chrome.linkedinUrl ?? "",
        showHeaderSocial: chrome.showHeaderSocial, showFooterSocial: chrome.showFooterSocial,
        logo: files.logo, hero: files.hero, about: files.about, icon: files.icon,
        clearLogo: clear.logo, clearHero: clear.hero, clearAbout: clear.about, clearIcon: clear.icon,
      } }).then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else setOk("Brand settings saved."); })
        .catch((err: Error) => setError(err.message));
    }}>
      <h1 className="text-3xl">Brand</h1>
      <Field label="Default theme">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={chrome.themeMode} onChange={(e) => setChrome({ ...chrome, themeMode: e.target.value as Chrome["themeMode"] })}>
          <option value="system">Follow the visitor’s device</option>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </Field>
      <Field label="Accent">
        <select className="min-h-11 rounded-xl border border-line bg-paper px-3" value={chrome.accent} onChange={(e) => setChrome({ ...chrome, accent: e.target.value as Chrome["accent"] })}>
          <option value="gold">Gold</option>
          <option value="blue">Soft blue</option>
          <option value="violet">Violet</option>
        </select>
      </Field>
      <Field label="YouTube"><TextInput value={chrome.youtubeUrl} onChange={(e) => setChrome({ ...chrome, youtubeUrl: e.target.value })} /></Field>
      <Field label="WhatsApp"><TextInput value={chrome.whatsappUrl} onChange={(e) => setChrome({ ...chrome, whatsappUrl: e.target.value })} /></Field>
      {(["facebookUrl", "instagramUrl", "tiktokUrl", "xUrl", "linkedinUrl"] as const).map((key) => (
        <Field key={key} label={key.replace("Url", "")} hint="Leave empty to hide the icon.">
          <TextInput value={chrome[key] ?? ""} onChange={(e) => setChrome({ ...chrome, [key]: e.target.value || null })} />
        </Field>
      ))}
      <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={chrome.showHeaderSocial} onChange={(e) => setChrome({ ...chrome, showHeaderSocial: e.target.checked })} /> Show social icons near the community section</label>
      <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={chrome.showFooterSocial} onChange={(e) => setChrome({ ...chrome, showFooterSocial: e.target.checked })} /> Show social icons in the footer</label>
      <Upload label="Logo" onFile={(file) => void onFile("logo", file)} clear={() => setClear({ ...clear, logo: true })} />
      <Upload label="Homepage image" onFile={(file) => void onFile("hero", file)} clear={() => setClear({ ...clear, hero: true })} />
      <Upload label="About image" onFile={(file) => void onFile("about", file)} clear={() => setClear({ ...clear, about: true })} />
      <Upload label="Browser icon" onFile={(file) => void onFile("icon", file)} clear={() => setClear({ ...clear, icon: true })} />
      <p className="text-xs text-muted">The large link-preview image is published with the site’s share card. Replacing it in the browser icon slot changes the favicon served from this site.</p>
      <Button type="submit">Save brand</Button>
      <Status error={error} ok={ok} />
    </form>
  );
}

function Upload({ label, onFile, clear }: { label: string; onFile: (file?: File) => void; clear: () => void }) {
  return (
    <div className="grid gap-1">
      <span className="text-sm font-medium">{label}</span>
      <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => onFile(e.target.files?.[0])} />
      <button type="button" className="w-fit text-xs underline" onClick={clear}>Remove uploaded {label.toLowerCase()}</button>
    </div>
  );
}

function Seo() {
  const [chrome, setChrome] = useState<Chrome | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  useEffect(() => { getChrome().then(setChrome).catch(() => undefined); }, []);
  if (!chrome) return null;
  return (
    <form className="grid gap-3" onSubmit={(e) => {
      e.preventDefault();
      saveSeo({ data: { seoTitle: chrome.seoTitle, seoDescription: chrome.seoDescription, canonicalUrl: chrome.canonicalUrl } })
        .then((result) => { if (!result.ok) setError(result.error ?? "Could not save."); else setOk("SEO settings saved."); });
    }}>
      <h1 className="text-3xl">Search</h1>
      <Field label="Homepage title"><TextInput value={chrome.seoTitle} onChange={(e) => setChrome({ ...chrome, seoTitle: e.target.value })} /></Field>
      <Field label="Meta description"><TextArea value={chrome.seoDescription} onChange={(e) => setChrome({ ...chrome, seoDescription: e.target.value })} /></Field>
      <Field label="Canonical website"><TextInput value={chrome.canonicalUrl} onChange={(e) => setChrome({ ...chrome, canonicalUrl: e.target.value })} /></Field>
      <p className="text-sm text-muted">After you publish, open Google Search Console, add your domain, and submit the sitemap at {chrome.canonicalUrl}/sitemap.xml. Then request indexing for the homepage. Google does not index a new site immediately, and this website cannot force a logo to appear in search.</p>
      <p className="text-sm text-muted">Official links currently expected: {OFFICIAL.site}, {OFFICIAL.youtube}, {OFFICIAL.whatsapp}.</p>
      <Button type="submit">Save SEO</Button>
      <Status error={error} ok={ok} />
    </form>
  );
}

function Messages() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminMessages>>>([]);
  function reload() { adminMessages().then(setRows).catch(() => undefined); }
  useEffect(() => { reload(); }, []);
  return (
    <div className="grid gap-3">
      <h1 className="text-3xl">Messages</h1>
      {rows.map((row) => (
        <article key={row.id} className="rounded-card border border-line p-3 text-sm">
          <p className="font-medium">{row.name} · {row.email}</p>
          <p className="text-muted">{row.created_on} · {row.read ? "Read" : "Unread"}</p>
          <p className="mt-2 whitespace-pre-wrap">{row.message}</p>
          {!row.read ? <Button className="mt-2" type="button" variant="line" onClick={() => markMessage({ data: row.id }).then(reload)}>Mark read</Button> : null}
        </article>
      ))}
      {!rows.length ? <Empty title="No messages" body="Contact form submissions will be listed here." /> : null}
    </div>
  );
}

function Audit() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof adminAudit>>>([]);
  useEffect(() => { adminAudit().then(setRows).catch(() => undefined); }, []);
  return (
    <div>
      <h1 className="text-3xl">Audit log</h1>
      <Log rows={rows} />
    </div>
  );
}

function Log({ rows }: { rows: Array<{ id: number; action: string; entity: string; detail?: string | null; created_on: string }> }) {
  if (!rows.length) return <p className="mt-3 text-sm text-muted">No records yet.</p>;
  return (
    <ul className="mt-3 grid gap-2 text-sm">
      {rows.map((row) => <li key={row.id} className="rounded-xl border border-line px-3 py-2">{row.created_on} · {row.action} · {row.entity}{row.detail ? ` · ${row.detail}` : ""}</li>)}
    </ul>
  );
}

function Access() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  return (
    <div className="grid max-w-xl gap-4">
      <h1 className="text-3xl">Access and setup</h1>
      <Guide />
      <form className="grid gap-3" onSubmit={(e) => {
        e.preventDefault();
        rotateAccessCode({ data: { current, next } }).then((result) => {
          if (!result.ok) setError(result.error ?? "Could not change it.");
          else { setOk("The access code has been changed. The new code is stored as a hash, not as text."); setCurrent(""); setNext(""); }
        }).catch(() => setError("Could not change it."));
      }}>
        <Field label="Current access code"><TextInput type="password" value={current} onChange={(e) => setCurrent(e.target.value)} /></Field>
        <Field label="New access code" hint="At least 8 characters. It will not be shown again."><TextInput type="password" value={next} onChange={(e) => setNext(e.target.value)} /></Field>
        <Button type="submit">Change access code</Button>
        <Status error={error} ok={ok} />
      </form>
    </div>
  );
}

function Guide() {
  return (
    <div className="grid gap-3 text-sm text-muted">
      <p>Student accounts use email and password, or Google or X. Passwords are handled by the account system, not stored in plain text by this academy.</p>
      <p>The first administrator is an ordinary account plus the server access code. The code is read from the environment variable QIVENEX_ADMIN_ACCESS_CODE. It is not written into the public website. After the first successful claim, a hash is saved so later sign-ins can use the changed code from this screen.</p>
      <p>When you publish, add that same variable in the host’s environment if you have not already claimed the admin account on the published database. Without it, the claim screen will say the credential is not configured.</p>
      <p>Selar checkout links are external. There is no payment webhook in this version, so nothing is marked paid automatically. Verify payments yourself under Payments.</p>
      <p>YouTube and WhatsApp start as the official channels. Facebook, Instagram, TikTok, X, and LinkedIn stay hidden until you paste an https link.</p>
      <Box>What already works: public pages, registration, student dashboard, course publishing, manual enrollment, submissions, exams, certificates, contact form, themes, and this dashboard.</Box>
      <Box>What still needs you: a real contact email if you want one public, social links besides YouTube and WhatsApp, lesson uploads, exams, and checking Selar payments yourself.</Box>
    </div>
  );
}

function Box({ children }: { children: ReactNode }) {
  return <p className="rounded-xl border border-line bg-surface p-3 text-fg">{children}</p>;
}
