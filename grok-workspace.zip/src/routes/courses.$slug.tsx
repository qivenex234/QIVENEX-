import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { difficultyLabel, formatNaira } from "@/lib/academy";
import { getCatalog, getCoursePage } from "@/server/public";
import { recordCheckoutIntent } from "@/server/student";
import { Button } from "@/components/ui";

export const Route = createFileRoute("/courses/$slug")({
  loader: async ({ params }) => {
    const course = await getCoursePage({ data: params.slug });
    if (!course) throw notFound();
    const catalog = await getCatalog();
    return { course, plans: catalog.plans };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.course.title} · QIVENEX AI ACADEMY` : "Course" },
      { name: "description", content: loaderData?.course.description ?? "A course at QIVENEX AI ACADEMY." },
    ],
  }),
  component: CoursePage,
});

function CoursePage() {
  const { course, plans } = Route.useLoaderData();
  const user = useCurrentUser();
  const plan = plans.find((item) => item.code === course.planCode);
  const checkout = course.checkoutUrl || plan?.checkoutUrl;
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      {course.cover ? <img src={course.cover} alt="" className="aspect-video w-full rounded-card object-cover" /> : null}
      <p className="mt-6 text-xs tracking-widest text-accent-ink uppercase">{course.category}</p>
      <h1 className="mt-2 text-4xl sm:text-5xl">{course.title}</h1>
      <p className="mt-4 text-muted">{course.description}</p>
      <p className="mt-3 text-sm">{difficultyLabel(course.difficulty)}{plan ? ` · Included with ${plan.name} (${formatNaira(plan.priceNgn)})` : ""} · {course.lessonCount ? `${course.lessonCount} lesson${course.lessonCount === 1 ? "" : "s"} uploaded` : "No lessons uploaded yet"}</p>
      {course.outcomes.length ? (
        <ul className="mt-6 grid gap-2 text-sm">
          {course.outcomes.map((item) => <li key={item} className="rounded-xl border border-line px-3 py-2">{item}</li>)}
        </ul>
      ) : null}
      {course.curriculum ? <p className="mt-6 whitespace-pre-wrap text-sm text-muted">{course.curriculum}</p> : <p className="mt-6 text-sm text-muted">A full curriculum has not been added yet. Locked lesson text is available only after enrollment is verified.</p>}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        {checkout ? (
          <a
            href={checkout}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-11 items-center justify-center rounded-full bg-fg px-5 text-sm text-bg"
            onClick={() => {
              if (!user) return;
              void recordCheckoutIntent({ data: { planCode: course.planCode ?? undefined, courseId: course.id } }).catch(() => undefined);
            }}
          >
            Continue to secure checkout
          </a>
        ) : (
          <a href="/#pricing" className="inline-flex min-h-11 items-center justify-center rounded-full bg-fg px-5 text-sm text-bg">See plans</a>
        )}
        <Link to="/learn"><Button type="button" variant="line">Open student dashboard</Button></Link>
      </div>
      <p className="mt-3 text-xs text-muted">Checkout happens on Selar. Clicking it does not confirm payment or unlock the course.</p>
    </main>
  );
}
