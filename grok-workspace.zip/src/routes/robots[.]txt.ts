import { createFileRoute } from "@tanstack/react-router";
import { OFFICIAL } from "@/lib/academy";

export const Route = createFileRoute("/robots.txt")({
  server: {
    handlers: {
      GET: async () => {
        const { readChrome } = await import("@/server/shared");
        const chrome = await readChrome().catch(() => null);
        const origin = (chrome?.canonicalUrl || OFFICIAL.site).replace(/\/$/, "");
        const body = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /learn\nDisallow: /api/\n\nSitemap: ${origin}/sitemap.xml\n`;
        return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
      },
    },
  },
});
