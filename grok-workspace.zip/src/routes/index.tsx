import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/home-page";
import { getHome } from "@/server/public";

export const Route = createFileRoute("/")({
  loader: () => getHome(),
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData?.chrome.seoTitle ?? "QIVENEX AI ACADEMY" },
      { name: "description", content: loaderData?.chrome.seoDescription ?? "Practical AI courses from QIVENEX AI ACADEMY." },
    ],
    links: [{ rel: "canonical", href: `${loaderData?.chrome.canonicalUrl ?? "https://qivenexaiacademy.lovable.app"}/` }],
  }),
  component: () => {
    const data = Route.useLoaderData();
    return <HomePage data={data} />;
  },
});
