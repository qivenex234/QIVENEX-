import type { ReactNode } from "react";
import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Shell } from "@/components/shell";
import { getChrome } from "@/server/public";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  loader: () => getChrome(),
  head: ({ loaderData }) => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: loaderData?.seoTitle ?? "QIVENEX AI ACADEMY" },
      { name: "description", content: loaderData?.seoDescription ?? "QIVENEX AI ACADEMY teaches practical AI skills." },
      { name: "theme-color", media: "(prefers-color-scheme: light)", content: "#f3eee6" },
      { name: "theme-color", media: "(prefers-color-scheme: dark)", content: "#100e0c" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,520;9..144,620&family=Outfit:wght@400;500;600&display=swap",
      },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "canonical", href: `${loaderData?.canonicalUrl ?? "https://qivenexaiacademy.lovable.app"}/` },
    ],
  }),
  shellComponent: RootShell,
  component: Root,
  notFoundComponent: () => (
    <Shell>
      <main className="mx-auto max-w-xl px-4 py-20">
        <h1 className="text-4xl">That page is not here</h1>
        <p className="mt-3 text-muted">The link may be old, or the page has not been published.</p>
      </main>
    </Shell>
  ),
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem("qivenex-theme");if(t==="light"||t==="dark")document.documentElement.setAttribute("data-theme",t);}catch(e){}})();`,
          }}
        />
        <PreviewHostBridge />
        <AuthProvider>{children}</AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function Root() {
  return (
    <Shell>
      <Outlet />
    </Shell>
  );
}
