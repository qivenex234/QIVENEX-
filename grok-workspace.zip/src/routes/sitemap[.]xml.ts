import { createFileRoute } from "@tanstack/react-router";
import { OFFICIAL } from "@/lib/academy";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const { readChrome, db } = await import("@/server/shared");
        const chrome = await readChrome().catch(() => null);
        const origin = (chrome?.canonicalUrl || OFFICIAL.site).replace(/\/$/, "");
        const sql = await db();
        const courses = await sql<{ slug: string }>`select slug from courses where published = true order by sort_order`;
        const certs = await sql<{ public_id: string }>`select public_id from certificates order by issued_at desc limit 200`;
        const urls = [
          "/",
          "/courses",
          "/projects",
          "/community",
          "/faq",
          "/contact",
          ...courses.map((course) => `/courses/${course.slug}`),
          ...certs.map((cert) => `/certificate/${cert.public_id}`),
        ];
        const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
          .map((path) => `  <url><loc>${origin}${path}</loc></url>`)
          .join("\n")}\n</urlset>\n`;
        return new Response(body, { headers: { "Content-Type": "application/xml; charset=utf-8" } });
      },
    },
  },
});
