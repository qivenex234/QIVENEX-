import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useChrome } from "@/components/shell";
import { submitContact } from "@/server/public";
import { PageIntro } from "@/components/shell";
import { Button, Status, TextArea, TextInput } from "@/components/ui";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact · QIVENEX AI ACADEMY" },
      { name: "description", content: "Contact QIVENEX AI ACADEMY. Messages are reviewed by the academy." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const chrome = useChrome();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [company, setCompany] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  return (
    <main className="mx-auto max-w-xl px-4 pb-12">
      <PageIntro eyebrow="Hello" title="Contact the academy" body={chrome.contactNote} />
      {chrome.contactEmail ? <p className="mt-4 text-sm">Email: <a className="underline" href={`mailto:${chrome.contactEmail}`}>{chrome.contactEmail}</a></p> : <p className="mt-4 text-sm text-muted">No public email or phone number has been added.</p>}
      <form className="mt-6 grid gap-3" onSubmit={(event) => {
        event.preventDefault();
        setPending(true);
        setError(null);
        submitContact({ data: { name, email, message, company } })
          .then((result) => {
            if (!result.ok) setError(result.error);
            else { setOk("Your message has been received."); setName(""); setEmail(""); setMessage(""); }
          })
          .catch(() => setError("The message could not be sent."))
          .finally(() => setPending(false));
      }}>
        <div className="absolute h-0 overflow-hidden">
          <label>Company<input value={company} onChange={(event) => setCompany(event.target.value)} tabIndex={-1} autoComplete="off" /></label>
        </div>
        <TextInput aria-label="Name" placeholder="Your name" value={name} onChange={(event) => setName(event.target.value)} required />
        <TextInput aria-label="Email" type="email" placeholder="Email address" value={email} onChange={(event) => setEmail(event.target.value)} required />
        <TextArea aria-label="Message" placeholder="Your message" value={message} onChange={(event) => setMessage(event.target.value)} required />
        <Button type="submit" disabled={pending}>{pending ? "Sending…" : "Send message"}</Button>
        <Status error={error} ok={ok} />
      </form>
    </main>
  );
}
