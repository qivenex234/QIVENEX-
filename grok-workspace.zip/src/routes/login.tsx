import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { Button, Field, Status, TextInput } from "@/components/ui";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in · QIVENEX AI ACADEMY" },
      { name: "description", content: "Create a student account or sign in to QIVENEX AI ACADEMY." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (password.length < 8) {
      setError("Use at least 8 characters for the password.");
      return;
    }
    setPending(true);
    try {
      if (mode === "up") {
        if (name.trim().length < 2) {
          setError("Enter the name you want on your account.");
          setPending(false);
          return;
        }
        const { error: signError } = await authClient.signUp.email({
          email: email.trim(),
          password,
          name: name.trim(),
        });
        if (signError) throw new Error(signError.message ?? "Could not create the account.");
      } else {
        const { error: signError } = await authClient.signIn.email({
          email: email.trim(),
          password,
        });
        if (signError) throw new Error(signError.message ?? "Could not sign in.");
      }
      await authClient.getSession();
      await navigate({ to: "/learn" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not continue.");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-[70vh] max-w-md place-items-center px-4 py-12">
      <div className="w-full">
        <p className="text-xs tracking-widest text-accent-ink uppercase">QIVENEX AI ACADEMY</p>
        <h1 className="mt-2 text-4xl">{mode === "up" ? "Create a student account" : "Welcome back"}</h1>
        <p className="mt-3 text-sm text-muted">Registration creates a student account only. It does not make you an administrator.</p>
        <div className="mt-5 grid gap-2">
          {GROK_PROVIDERS.map((provider) => (
            <Button key={provider.providerId} type="button" variant="line" onClick={() => void signIn(provider.providerId, { callbackURL: "/learn" }).catch((err: Error) => setError(err.message))}>
              Continue with {provider.label}
            </Button>
          ))}
        </div>
        <form className="mt-6 grid gap-3" onSubmit={(event) => void submit(event)}>
          {mode === "up" ? (
            <Field label="Name"><TextInput value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required /></Field>
          ) : null}
          <Field label="Email"><TextInput type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" required /></Field>
          <Field label="Password" hint="At least 8 characters.">
            <TextInput type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === "up" ? "new-password" : "current-password"} required />
          </Field>
          <Button type="submit" disabled={pending}>{pending ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"}</Button>
          <Status error={error} />
        </form>
        <button type="button" className="mt-4 min-h-11 text-sm underline" onClick={() => { setMode(mode === "up" ? "in" : "up"); setError(null); }}>
          {mode === "up" ? "I already have an account" : "I need a new account"}
        </button>
      </div>
    </main>
  );
}
