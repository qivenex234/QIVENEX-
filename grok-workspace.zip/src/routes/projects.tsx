import { createFileRoute } from "@tanstack/react-router";
import { getCommunity } from "@/server/public";
import { PageIntro } from "@/components/shell";
import { Empty } from "@/components/ui";

export const Route = createFileRoute("/projects")({
  loader: () => getCommunity(),
  head: () => ({
    meta: [
      { title: "Student projects · QIVENEX AI ACADEMY" },
      { name: "description", content: "Approved student projects from QIVENEX AI ACADEMY. Nothing is shown until the academy publishes it." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const { projects } = Route.useLoaderData();
  return (
    <main className="mx-auto max-w-6xl px-4 pb-12">
      <PageIntro eyebrow="Showcase" title="Student projects" body="A project is public only after review. Display names are the names students chose. The academy does not publish invented success stories." />
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {projects.map((project) => (
          <article key={project.id} className="rounded-card border border-line bg-surface p-4">
            {project.hasImage ? <img src={`/brand/project-${project.id}`} alt="" className="mb-3 aspect-video w-full rounded-xl object-cover" /> : null}
            <h2 className="text-2xl">{project.title}</h2>
            <p className="mt-1 text-sm text-muted">{project.studentName} · {project.createdOn}</p>
            <p className="mt-3 text-sm">{project.description}</p>
            {project.skills ? <p className="mt-2 text-xs text-accent-ink">{project.skills}</p> : null}
            {project.videoUrl ? <a className="mt-2 inline-flex min-h-11 items-center text-sm underline" href={project.videoUrl} target="_blank" rel="noopener noreferrer">Watch the project</a> : null}
          </article>
        ))}
      </div>
      {!projects.length ? <div className="mt-8"><Empty title="No published projects yet" body="When a student submission is approved for the showcase, it will appear here with the student’s display name." /></div> : null}
    </main>
  );
}
