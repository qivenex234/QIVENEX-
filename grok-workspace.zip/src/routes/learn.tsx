import { createFileRoute } from "@tanstack/react-router";
import { LearnPage } from "@/components/learn-page";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Student dashboard · QIVENEX AI ACADEMY" },
      { name: "description", content: "Your courses, submissions, exams, and certificates at QIVENEX AI ACADEMY." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LearnPage,
});
