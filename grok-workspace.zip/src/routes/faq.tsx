import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { getHome } from "@/server/public";
import { PageIntro } from "@/components/shell";

export const Route = createFileRoute("/faq")({
  loader: () => getHome(),
  head: () => ({
    meta: [
      { title: "FAQ · QIVENEX AI ACADEMY" },
      { name: "description", content: "Answers about course access, payments, beginners, certificates, and support at QIVENEX AI ACADEMY." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  const { faqs } = Route.useLoaderData();
  return (
    <main className="mx-auto max-w-3xl px-4 pb-12">
      <PageIntro eyebrow="Help" title="Frequently asked questions" body="These answers can be edited by the academy. They describe how the website actually works." />
      <div className="mt-8 grid gap-2">
        {faqs.map((faq) => <Item key={faq.id} question={faq.question} answer={faq.answer} />)}
      </div>
    </main>
  );
}

function Item({ question, answer }: { question: string; answer: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border border-line bg-surface">
      <button type="button" className="flex min-h-11 w-full items-center justify-between gap-3 px-4 py-3 text-left" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        <span>{question}</span>
        <span aria-hidden="true">{open ? "–" : "+"}</span>
      </button>
      {open ? <p className="px-4 pb-4 text-sm text-muted">{answer}</p> : null}
    </div>
  );
}
