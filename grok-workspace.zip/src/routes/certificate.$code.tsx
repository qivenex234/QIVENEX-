import { createFileRoute } from "@tanstack/react-router";
import { verifyCertificate } from "@/server/public";

export const Route = createFileRoute("/certificate/$code")({
  loader: ({ params }) => verifyCertificate({ data: params.code }),
  head: ({ params }) => ({
    meta: [
      { title: `Certificate ${params.code} · QIVENEX AI ACADEMY` },
      { name: "description", content: "Check whether a QIVENEX AI ACADEMY certificate identifier is valid." },
    ],
  }),
  component: VerifyPage,
});

function VerifyPage() {
  const result = Route.useLoaderData();
  return (
    <main className="mx-auto max-w-xl px-4 py-16">
      <p className="text-xs tracking-widest text-accent-ink uppercase">Certificate check</p>
      {result.valid ? (
        <>
          <h1 className="mt-2 text-4xl">This certificate is valid</h1>
          <dl className="mt-6 grid gap-3 text-sm">
            <div><dt className="text-muted">Name</dt><dd>{result.studentName}</dd></div>
            <div><dt className="text-muted">Title</dt><dd>{result.title}</dd></div>
            <div><dt className="text-muted">Issued</dt><dd>{result.issuedOn}</dd></div>
            <div><dt className="text-muted">Identifier</dt><dd>{result.publicId}</dd></div>
          </dl>
          <p className="mt-4 text-xs text-muted">This page does not show an email address, a score, or payment details.</p>
        </>
      ) : (
        <>
          <h1 className="mt-2 text-4xl">No certificate matches that identifier</h1>
          <p className="mt-3 text-sm text-muted">Check the code and try again. A missing record means it was not issued, not that a person failed.</p>
        </>
      )}
    </main>
  );
}
