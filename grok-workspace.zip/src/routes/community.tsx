import { createFileRoute } from "@tanstack/react-router";
import { useChrome } from "@/components/shell";
import { getCommunity } from "@/server/public";
import { PageIntro } from "@/components/shell";
import { Empty } from "@/components/ui";

export const Route = createFileRoute("/community")({
  loader: () => getCommunity(),
  head: () => ({
    meta: [
      { title: "Community · QIVENEX AI ACADEMY" },
      { name: "description", content: "YouTube tutorials, the WhatsApp Channel, and announcements from QIVENEX AI ACADEMY." },
    ],
  }),
  component: CommunityPage,
});

function CommunityPage() {
  const chrome = useChrome();
  const { announcements, videos } = Route.useLoaderData();
  return (
    <main className="mx-auto max-w-6xl px-4 pb-12">
      <PageIntro eyebrow="Together" title="Community and classes" body="Follow the official channels and read announcements the academy has actually published." />
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <a href={chrome.youtubeUrl} target="_blank" rel="noopener noreferrer" className="rounded-card border border-line bg-surface p-5">
          <h2 className="text-2xl">Watch tutorials on YouTube</h2>
          <p className="mt-2 text-sm text-muted">{chrome.youtubeUrl}</p>
        </a>
        <a href={chrome.whatsappUrl} target="_blank" rel="noopener noreferrer" className="rounded-card border border-line bg-surface p-5">
          <h2 className="text-2xl">Join the WhatsApp Channel</h2>
          <p className="mt-2 text-sm text-muted">{chrome.whatsappUrl}</p>
        </a>
      </div>
      <div className="mt-8 grid gap-3">
        {announcements.map((item) => (
          <article key={item.id} className="rounded-card border border-line p-4">
            <p className="text-xs tracking-widest text-muted uppercase">{item.kind} · {item.createdOn}</p>
            <h2 className="mt-1 text-2xl">{item.title}</h2>
            <p className="mt-2 text-sm text-muted">{item.body}</p>
          </article>
        ))}
        {!announcements.length ? <Empty title="No announcements yet" body="Class schedules, bootcamps, and notices will be listed when they are published." /> : null}
      </div>
      {videos.length ? (
        <ul className="mt-6 grid gap-2">
          {videos.map((video) => <li key={video.id}><a className="underline" href={video.url} target="_blank" rel="noopener noreferrer">{video.title}</a></li>)}
        </ul>
      ) : null}
    </main>
  );
}
