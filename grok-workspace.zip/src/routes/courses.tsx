import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { difficultyLabel } from "@/lib/academy";
import { getCatalog } from "@/server/public";
import { PageIntro } from "@/components/shell";
import { Empty } from "@/components/ui";

export const Route = createFileRoute("/courses")({
  loader: () => getCatalog(),
  head: () => ({
    meta: [
      { title: "Courses · QIVENEX AI ACADEMY" },
      { name: "description", content: "Practical AI courses at QIVENEX AI ACADEMY, from tools and content to apps, video, and digital products." },
    ],
  }),
  component: CoursesPage,
});

function CoursesPage() {
  const { courses } = Route.useLoaderData();
  const categories = ["All", ...Array.from(new Set(courses.map((course) => course.category)))];
  const [category, setCategory] = useState("All");
  const shown = courses.filter((course) => category === "All" || course.category === category);
  return (
    <main className="pb-12">
      <PageIntro eyebrow="Catalogue" title="Courses" body="Every course can be edited, hidden, or reordered by the academy. Lesson files are listed only when they have actually been uploaded." />
      <div className="mx-auto mt-6 flex max-w-6xl gap-2 overflow-x-auto px-4">
        {categories.map((item) => (
          <button key={item} type="button" className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${category === item ? "bg-fg text-bg" : "border border-line"}`} onClick={() => setCategory(item)}>
            {item}
          </button>
        ))}
      </div>
      <div className="mx-auto mt-6 grid max-w-6xl gap-4 px-4 sm:grid-cols-2">
        {shown.map((course) => (
          <Link key={course.id} to="/courses/$slug" params={{ slug: course.slug }} className="overflow-hidden rounded-card border border-line bg-surface">
            {course.cover ? <img src={course.cover} alt="" className="aspect-video w-full object-cover" /> : null}
            <div className="p-4">
              <p className="text-xs text-accent-ink">{course.category}</p>
              <h2 className="mt-1 text-2xl">{course.title}</h2>
              <p className="mt-2 text-sm text-muted">{course.description}</p>
              <p className="mt-3 text-xs text-muted">{difficultyLabel(course.difficulty)} · {course.lessonCount ? `${course.lessonCount} lesson${course.lessonCount === 1 ? "" : "s"} uploaded` : "No lessons uploaded yet"}</p>
            </div>
          </Link>
        ))}
      </div>
      {!shown.length ? <div className="mx-auto mt-6 max-w-6xl px-4"><Empty title="Nothing in this category" body="Published courses will show here." /></div> : null}
    </main>
  );
}
