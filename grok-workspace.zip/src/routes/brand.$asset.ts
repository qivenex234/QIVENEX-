import { createFileRoute } from "@tanstack/react-router";
import { serveBrand } from "@/server/public";

export const Route = createFileRoute("/brand/$asset")({
  server: {
    handlers: {
      GET: async ({ params }) => serveBrand(params.asset),
    },
  },
});
