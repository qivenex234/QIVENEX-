import { createFileRoute } from "@tanstack/react-router";
import { AdminPage } from "@/components/admin-page";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin · QIVENEX AI ACADEMY" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});
