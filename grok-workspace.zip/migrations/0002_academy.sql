-- QIVENEX AI ACADEMY application schema.
-- Authorization is enforced in server functions. There is no public SQL API.

create table if not exists profiles (
  user_id text primary key references "user"(id) on delete cascade,
  display_name text not null,
  role text not null default 'student',
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_role_chk check (role in ('student', 'admin')),
  constraint profiles_status_chk check (status in ('active', 'suspended'))
);

create table if not exists admin_credential (
  id int primary key default 1 check (id = 1),
  hash text not null,
  updated_at timestamptz not null default now()
);

create table if not exists site_settings (
  id int primary key default 1 check (id = 1),
  hero_kicker text not null,
  hero_title text not null,
  hero_body text not null,
  about_title text not null,
  about_body text not null,
  founder_note text not null,
  contact_email text,
  contact_note text not null,
  seo_title text not null,
  seo_description text not null,
  canonical_url text not null,
  theme_mode text not null default 'system',
  accent text not null default 'gold',
  youtube_url text not null,
  whatsapp_url text not null,
  facebook_url text,
  instagram_url text,
  tiktok_url text,
  x_url text,
  linkedin_url text,
  show_header_social boolean not null default true,
  show_footer_social boolean not null default true,
  sections jsonb not null,
  logo_data text,
  favicon_data text,
  hero_image text,
  about_image text,
  auto_issue_certificates boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists plans (
  code text primary key,
  name text not null,
  price_ngn int not null,
  description text not null,
  features jsonb not null,
  checkout_url text not null,
  published boolean not null default true,
  sort_order int not null default 0
);

create table if not exists courses (
  id serial primary key,
  slug text not null unique,
  title text not null,
  description text not null,
  category text not null,
  difficulty text not null,
  plan_code text references plans(code),
  checkout_url text,
  outcomes jsonb not null default '[]'::jsonb,
  curriculum text,
  cover text,
  published boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists lessons (
  id serial primary key,
  course_id int not null references courses(id) on delete cascade,
  title text not null,
  body text not null default '',
  material_url text,
  sort_order int not null default 0
);

create table if not exists enrollments (
  id serial primary key,
  user_id text not null,
  course_id int references courses(id) on delete set null,
  plan_code text,
  status text not null default 'pending',
  source text not null,
  note text,
  verified_by text,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  constraint enrollments_status_chk check (status in ('pending', 'verified', 'revoked'))
);

create index if not exists enrollments_user_idx on enrollments (user_id);

create table if not exists submissions (
  id serial primary key,
  user_id text not null,
  title text not null,
  description text not null,
  skills text not null default '',
  media_data text,
  video_url text,
  status text not null default 'pending',
  showcase boolean not null default false,
  admin_note text,
  created_at timestamptz not null default now(),
  constraint submissions_status_chk check (status in ('pending', 'approved', 'rejected'))
);

create index if not exists submissions_user_idx on submissions (user_id);

create table if not exists announcements (
  id serial primary key,
  title text not null,
  body text not null,
  kind text not null default 'news',
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists faqs (
  id serial primary key,
  question text not null,
  answer text not null,
  sort_order int not null default 0,
  published boolean not null default true
);

create table if not exists featured_videos (
  id serial primary key,
  title text not null,
  url text not null,
  published boolean not null default true,
  sort_order int not null default 0
);

create table if not exists exams (
  id serial primary key,
  title text not null,
  instructions text not null default '',
  course_id int references courses(id) on delete set null,
  pass_mark int not null default 50,
  deadline timestamptz,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists exam_questions (
  id serial primary key,
  exam_id int not null references exams(id) on delete cascade,
  prompt text not null,
  options jsonb not null,
  correct_index int not null,
  points int not null default 1,
  sort_order int not null default 0
);

create table if not exists exam_attempts (
  id serial primary key,
  exam_id int not null references exams(id) on delete cascade,
  user_id text not null,
  answers jsonb not null,
  score int not null,
  max_score int not null,
  passed boolean not null,
  submitted_at timestamptz not null default now(),
  unique (exam_id, user_id)
);

create table if not exists certificates (
  id serial primary key,
  public_id text not null unique,
  user_id text not null,
  exam_id int references exams(id) on delete set null,
  student_name text not null,
  title text not null,
  issued_at timestamptz not null default now()
);

create index if not exists certificates_user_idx on certificates (user_id);

create table if not exists contact_messages (
  id serial primary key,
  name text not null,
  email text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id serial primary key,
  actor_id text,
  action text not null,
  entity text not null,
  entity_id text,
  detail text,
  created_at timestamptz not null default now()
);

create table if not exists rate_limits (
  bucket text primary key,
  hits int not null,
  window_start timestamptz not null default now()
);

insert into site_settings (
  id, hero_kicker, hero_title, hero_body, about_title, about_body, founder_note,
  contact_email, contact_note, seo_title, seo_description, canonical_url,
  theme_mode, accent, youtube_url, whatsapp_url, sections
) values (
  1,
  'Welcome to QIVENEX AI ACADEMY',
  'Learn AI. Build Your Ideas. Create Your Future.',
  'Learn practical AI skills, create digital content, build applications and websites, and turn your knowledge into useful digital products. QIVENEX AI ACADEMY gives you a place to learn, practise, and grow—one skill at a time.',
  'A practical place to learn AI',
  'QIVENEX AI ACADEMY focuses on practical, accessible AI education. Students learn by doing, follow guided projects, develop usable skills, and take part in a community that is building digital products. The work is paced so a beginner can start without pretending the subject is magic.',
  'Chris Vincent is the founder of QIVENEX AI ACADEMY. This page does not invent qualifications, awards, or an employment history. Those details appear only if he chooses to publish them.',
  null,
  'Use this form to reach the academy. Messages are stored for the administrator. No phone number is published here.',
  'QIVENEX AI ACADEMY — Learn practical AI skills',
  'QIVENEX AI ACADEMY, founded by Chris Vincent, teaches practical AI skills for beginners and entrepreneurs: tools, content, video, apps, websites, and digital products.',
  'https://qivenexaiacademy.lovable.app',
  'system',
  'gold',
  'https://www.youtube.com/@qivenexacademy',
  'https://whatsapp.com/channel/0029Vb8lkx0AzNbozwWJd12x',
  '{"about":true,"courses":true,"pricing":true,"projects":true,"community":true,"faq":true,"contact":true}'::jsonb
) on conflict (id) do nothing;

insert into plans (code, name, price_ngn, description, features, checkout_url, published, sort_order) values
(
  'starter',
  'Starter',
  5000,
  'A first step into practical AI skills, with access to Starter courses after the academy verifies your payment.',
  '["Starter courses after an administrator verifies payment","Student dashboard, announcements, and project submission","Community links for YouTube and WhatsApp"]'::jsonb,
  'https://selar.com/5e16655d91',
  true,
  1
),
(
  'basic',
  'Basic',
  10000,
  'Starter plus the Basic courses. Payment is completed on Selar and access opens only after verification.',
  '["Everything in Starter","Basic courses after verification","Reviewed project feedback when the academy has marked your submission"]'::jsonb,
  'https://selar.com/716p7u4a6b',
  true,
  2
),
(
  'standard',
  'Standard',
  20000,
  'The fullest plan: Starter, Basic, and Standard courses, including guided project pathways that the academy publishes.',
  '["Everything in Basic","Standard courses after verification","Guided project pathway where a project is published","Exam eligibility only when an exam is actually published"]'::jsonb,
  'https://selar.com/4d167101ig',
  true,
  3
)
on conflict (code) do nothing;

insert into courses (slug, title, description, category, difficulty, plan_code, outcomes, cover, published, sort_order) values
('ai-tools-and-productivity', 'AI tools and productivity', 'Choose everyday AI tools and use them for writing, research, planning, and simple work routines.', 'AI tools and productivity', 'beginner', 'starter', '["Pick a small set of tools you will actually use","Turn a task into a clear prompt and a finished draft","Build a simple weekly workflow"]'::jsonb, '/media/build.jpg', true, 1),
('ai-video-creation', 'AI video creation', 'Plan, generate, and assemble short videos with AI tools, from idea to a watchable cut.', 'AI video creation', 'beginner', 'basic', '["Outline a short video before generating anything","Generate and select usable clips","Assemble a simple cut with a clear beginning and end"]'::jsonb, '/media/camera.jpg', true, 2),
('cinematic-ai-video', 'Cinematic AI video creation', 'Go further into shots, pacing, and finishing so AI video feels deliberate.', 'Cinematic AI video creation', 'intermediate', 'standard', '["Plan shots instead of generating at random","Shape pacing, light, and sequence","Finish a short piece you can show"]'::jsonb, '/media/camera.jpg', true, 3),
('ai-content-creation', 'AI content creation', 'Turn ideas into posts, scripts, and other pieces you can publish.', 'AI content creation', 'beginner', 'starter', '["Find a subject a real audience can use","Draft and revise with AI as an assistant","Prepare a piece that is ready to publish"]'::jsonb, '/media/build.jpg', true, 4),
('ai-application-building', 'AI application building', 'Plan a small application and shape it with AI-assisted building tools.', 'AI application building', 'intermediate', 'standard', '["Describe what the application must do","Break the idea into screens and data","Build a small working version"]'::jsonb, '/media/studio.jpg', true, 5),
('google-opal-applications', 'Building applications with Google Opal', 'A focused path for building small applications with Google Opal.', 'Building applications with Google Opal', 'intermediate', 'basic', '["Understand what Opal is being used for","Build a small application flow","Check that the result does what you intended"]'::jsonb, '/media/studio.jpg', true, 6),
('website-creation-with-ai', 'Website creation using AI', 'Plan, generate, and refine a simple website with AI assistance.', 'Website creation using AI', 'beginner', 'basic', '["Decide what the page must say","Generate a first version and edit it honestly","Publish a page a visitor can understand"]'::jsonb, '/media/build.jpg', true, 7),
('ai-automation', 'AI automation', 'See where automation helps, and connect simple steps so repeated work takes less effort.', 'AI automation', 'intermediate', 'standard', '["Spot a repeated task worth automating","Connect a short sequence of steps","Know when a person should still check the result"]'::jsonb, '/media/studio.jpg', true, 8),
('ai-business-and-monetization', 'AI business and monetization', 'Explore practical ways to package AI skills as offers, services, and small digital businesses.', 'AI business and monetization', 'beginner', 'basic', '["Name a person you can help","Describe an offer in plain language","List the next honest step to test it"]'::jsonb, '/media/build.jpg', true, 9),
('digital-products-and-ebooks', 'Digital product and ebook creation', 'Outline, draft, and prepare a digital product or ebook.', 'Digital product and ebook creation', 'beginner', 'starter', '["Choose a useful, narrow topic","Outline and draft the product","Prepare it so someone else can read it"]'::jsonb, '/media/build.jpg', true, 10),
('games-and-interactive-projects', 'Game and interactive project development', 'Build a small interactive project and understand the pieces that make it work.', 'Game and interactive project development', 'intermediate', 'standard', '["Scope a project small enough to finish","Build the interaction","Explain what you made"]'::jsonb, '/media/camera.jpg', true, 11),
('guided-projects-and-services', 'Special guided projects and build-for-you services', 'A place for guided builds and done-with-you project work arranged by the academy. Availability is announced by the administrator. This listing is not an automatic purchase of a custom build.', 'Special guided projects and build-for-you services', 'advanced', 'standard', '["See when a guided project is actually open","Understand what you will make","Submit your work for review"]'::jsonb, '/media/studio.jpg', true, 12)
on conflict (slug) do nothing;

insert into faqs (question, answer, sort_order, published) values
(
  'How do I get access after I pay?',
  'Payment is completed on Selar, not on this website. Opening a checkout does not mark you as paid. Create a student account, then either wait for an administrator to verify the payment or use “I have paid” in your dashboard. Access opens only after that verification.',
  1, true
),
(
  'I am a beginner. Can I start here?',
  'Yes. The academy is for beginners and entrepreneurs as well as people who already make digital products. Each course shows a difficulty. You do not need a technical background to create an account.',
  2, true
),
(
  'What do I need in order to learn?',
  'A phone or computer with an internet connection, and an account on this website. If a lesson needs another free tool, the lesson will say so. Lessons appear only after the academy uploads them.',
  3, true
),
(
  'Do you issue certificates?',
  'A certificate is created only for a student who meets a published exam requirement and has a certificate issued for that result. Each certificate has its own identifier. Anyone can check that identifier on the public verification page. Enrolling or clicking a payment link does not create a certificate.',
  4, true
),
(
  'How do I get support?',
  'Use the contact form. You can also follow announcements on the WhatsApp Channel and tutorials on YouTube. This website does not publish a phone number.',
  5, true
),
(
  'What does a plan include?',
  'Starter opens Starter courses. Basic opens Starter and Basic. Standard opens all three levels. A course page says which plan it belongs to. Nothing in a locked course is available until your enrollment is verified.',
  6, true
);
